import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '@/contexts/AuthContext';
import { rewardsService, BadgeReward } from '@/lib/rewards';
import { 
  Award,
  Trophy,
  Star,
  Gift,
  Target,
  TrendingUp,
  Calendar,
  Coins,
  Crown,
  Shield,
  Zap,
  Flame,
  RefreshCw,
  Sparkles
} from 'lucide-react-native';

interface Achievement {
  id: string;
  title: string;
  description: string;
  progress: number;
  target: number;
  reward: string;
  icon: any;
  color: string;
  completed: boolean;
}

export default function Rewards() {
  const { user } = useAuth();
  const [selectedTab, setSelectedTab] = useState<'rewards' | 'achievements'>('rewards');
  const [rewards, setRewards] = useState<BadgeReward[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [checkingBadges, setCheckingBadges] = useState(false);
  
  const [achievements] = useState<Achievement[]>([
    {
      id: '1',
      title: 'Savings Streak',
      description: 'Save money for 30 consecutive days',
      progress: 25,
      target: 30,
      reward: 'Streak Master Badge',
      icon: Calendar,
      color: '#EF4444',
      completed: false,
    },
    {
      id: '2',
      title: 'Budget Perfectionist',
      description: 'Stay within budget for 3 months',
      progress: 2,
      target: 3,
      reward: 'Perfect Planner Token',
      icon: Star,
      color: '#F59E0B',
      completed: false,
    },
    {
      id: '3',
      title: 'Emergency Fund Builder',
      description: 'Build emergency fund worth 6 months expenses',
      progress: 18000,
      target: 25000,
      reward: 'Security Shield NFT',
      icon: Shield,
      color: '#8B5CF6',
      completed: false,
    },
    {
      id: '4',
      title: 'Expense Eliminator',
      description: 'Reduce monthly expenses by 20%',
      progress: 15,
      target: 20,
      reward: 'Efficiency Expert Badge',
      icon: TrendingUp,
      color: '#10B981',
      completed: false,
    },
  ]);

  useEffect(() => {
    if (user) {
      loadRewards();
    }
  }, [user]);

  const loadRewards = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const userRewards = await rewardsService.getUserRewards(user.id);
      setRewards(userRewards);
    } catch (error) {
      console.error('Error loading rewards:', error);
      Alert.alert('Error', 'Failed to load rewards');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadRewards();
    setRefreshing(false);
  };

  const checkForNewBadges = async () => {
    console.log('Check for new badges button pressed');
    
    if (!user) {
      Alert.alert('Error', 'Please sign in to check for badges');
      return;
    }

    try {
      setCheckingBadges(true);
      
      // Show immediate feedback
      Alert.alert(
        '🔍 Checking for New Badges',
        'Analyzing your savings patterns and calculating potential rewards...',
        [{ text: 'OK' }]
      );

      const result = await rewardsService.triggerMonthlySavingsCheck(user.id);
      
      if (result.success) {
        // Success - new badge earned!
        Alert.alert(
          '🎉 New Badge Earned!',
          result.message,
          [
            { 
              text: 'View Badge', 
              onPress: async () => {
                await loadRewards(); // Reload to show new badge
              }
            }
          ]
        );
      } else {
        // No new badge or already exists
        Alert.alert(
          '📊 Badge Check Complete',
          result.message,
          [{ text: 'Keep Saving!' }]
        );
      }
    } catch (error) {
      console.error('Error checking for badges:', error);
      Alert.alert(
        'Error',
        'Failed to check for new badges. Please try again later.',
        [{ text: 'OK' }]
      );
    } finally {
      setCheckingBadges(false);
    }
  };

  const showAIFeatures = () => {
    console.log('AI Features button pressed in Rewards tab');
    
    // Enhanced alert with better structure and more information
    Alert.alert(
      '✨ AI-Powered Blockchain Rewards System',
      'Your rewards are powered by cutting-edge AI and blockchain technology:\n\n🤖 Artificial Intelligence Features:\n• Smart spending pattern analysis\n• Automatic savings calculations\n• Intelligent badge rarity determination\n• Predictive financial insights\n• Personalized reward recommendations\n\n⛓️ Blockchain Technology:\n• Permanent ownership on Algorand\n• Cryptographically verified badges\n• Immutable achievement records\n• Environmentally friendly proof-of-stake\n• Cannot be duplicated or faked',
      [
        { 
          text: 'Learn More', 
          onPress: () => {
            console.log('Learn More pressed from AI Features');
            showTechnicalDetails();
          }
        },
        { 
          text: 'Check for New Badges', 
          onPress: () => {
            console.log('Check for Badges from AI Features pressed');
            checkForNewBadges();
          }
        },
        { text: 'Got It!', style: 'default' }
      ]
    );
  };

  const showTechnicalDetails = () => {
    console.log('Technical Details pressed');
    
    Alert.alert(
      '🔬 Technical Architecture',
      'Our advanced system combines multiple technologies:\n\n🧠 Machine Learning:\n• Pattern recognition algorithms\n• Predictive analytics\n• Behavioral analysis\n• Risk assessment models\n\n⛓️ Blockchain Infrastructure:\n• Algorand blockchain integration\n• Smart contract automation\n• Cryptographic security\n• Decentralized verification\n\n🔒 Security Features:\n• End-to-end encryption\n• Multi-signature validation\n• Zero-knowledge proofs\n• Immutable transaction records',
      [
        { 
          text: 'Privacy & Security', 
          onPress: () => {
            console.log('Privacy Policy pressed');
            showPrivacyInfo();
          }
        },
        { 
          text: 'How It Works', 
          onPress: () => {
            console.log('How It Works pressed');
            showHowItWorks();
          }
        },
        { text: 'Back', style: 'cancel' }
      ]
    );
  };

  const showPrivacyInfo = () => {
    Alert.alert(
      '🛡️ Privacy & Data Protection',
      'Your data security is our top priority:\n\n🔐 Encryption:\n• Bank-level AES-256 encryption\n• Secure data transmission\n• Encrypted local storage\n\n🚫 Privacy Guarantees:\n• Zero data sharing with third parties\n• No personal data on blockchain\n• GDPR and CCPA compliant\n• Right to data portability\n\n✅ Your Rights:\n• Full data ownership\n• Transparent usage policies\n• Regular security audits\n• 24/7 monitoring',
      [
        { text: 'Contact Support', onPress: () => {
          Alert.alert('Support', 'Email: privacy@financecoach.app\nPhone: +91 98765 43210');
        }},
        { text: 'Understood', style: 'default' }
      ]
    );
  };

  const showHowItWorks = () => {
    Alert.alert(
      '⚙️ How AI Rewards Work',
      'Step-by-step process of earning blockchain badges:\n\n1️⃣ Savings Analysis:\n• AI monitors your monthly savings\n• Calculates income vs expenses\n• Identifies saving patterns\n\n2️⃣ Badge Qualification:\n• ₹1000+ = Common Badge\n• ₹2500+ = Rare Badge\n• ₹5000+ = Epic Badge\n• ₹10000+ = Legendary Badge\n\n3️⃣ Blockchain Minting:\n• Unique token generated\n• Stored on Algorand blockchain\n• Permanent ownership assigned\n• Cannot be duplicated\n\n4️⃣ Reward Distribution:\n• Badge appears in your collection\n• Viewable on blockchain explorer\n• Tradeable (future feature)',
      [
        { text: 'Try Now', onPress: checkForNewBadges },
        { text: 'Cool!', style: 'default' }
      ]
    );
  };

  const viewOnBlockchain = (tokenId: string) => {
    console.log('View on blockchain pressed for token:', tokenId);
    
    Alert.alert(
      '🔗 View on Algorand Blockchain',
      `Token ID: ${tokenId}\n\nThis badge is permanently stored on the Algorand blockchain, making it truly yours forever!\n\n🌐 Blockchain Features:\n• Immutable ownership record\n• Cryptographically verified\n• Publicly viewable\n• Cannot be counterfeited\n• Environmentally sustainable`,
      [
        { text: 'Close', style: 'cancel' },
        { 
          text: 'Learn About Algorand', 
          onPress: () => {
            console.log('Learn More about blockchain pressed');
            Alert.alert(
              '🌐 Algorand Blockchain',
              'Your rewards are secured using Algorand blockchain technology:\n\n⚡ Fast & Efficient:\n• 4.5 second transaction finality\n• Low transaction fees\n• High throughput\n\n🌱 Environmentally Friendly:\n• Carbon negative blockchain\n• Proof-of-stake consensus\n• Energy efficient\n\n🔒 Secure & Reliable:\n• Cryptographically secure\n• Decentralized network\n• Battle-tested technology\n\nYour achievements are truly yours forever!'
            );
          }
        },
      ]
    );
  };

  const getIconForRewardType = (rewardType: string) => {
    switch (rewardType.toLowerCase()) {
      case 'legendary saver': return Flame;
      case 'epic saver': return Crown;
      case 'rare saver': return Trophy;
      case 'saver badge': return Shield;
      default: return Award;
    }
  };

  const RewardCard = ({ reward }: { reward: BadgeReward }) => {
    const IconComponent = getIconForRewardType(reward.rewardType);
    const color = rewardsService.getBadgeColor(reward.rarity);
    
    return (
      <TouchableOpacity 
        style={[styles.rewardCard, { borderColor: color }]}
        onPress={() => viewOnBlockchain(reward.tokenId)}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={[color + '20', color + '10']}
          style={styles.rewardGradient}
        >
          <View style={styles.rewardHeader}>
            <View style={[styles.rewardIcon, { backgroundColor: color }]}>
              <IconComponent size={24} color="white" />
            </View>
            <View style={[styles.rarityBadge, { backgroundColor: color }]}>
              <Text style={styles.rarityText}>{reward.rarity}</Text>
            </View>
          </View>
          
          <Text style={styles.rewardTitle}>{reward.rewardType}</Text>
          <Text style={styles.rewardDescription}>
            Saved ₹{reward.amountSaved.toLocaleString()} in {reward.month}
          </Text>
          
          <View style={styles.rewardFooter}>
            <View style={styles.rewardInfo}>
              <Text style={styles.rewardAmount}>
                ₹{reward.amountSaved.toLocaleString()}
              </Text>
              <Text style={styles.rewardMonth}>{reward.month}</Text>
            </View>
            <View style={styles.tokenInfo}>
              <Coins size={16} color="#6B7280" />
              <Text style={styles.tokenId}>{reward.tokenId}</Text>
            </View>
          </View>
        </LinearGradient>
      </TouchableOpacity>
    );
  };

  const AchievementCard = ({ achievement }: { achievement: Achievement }) => {
    const progressPercentage = (achievement.progress / achievement.target) * 100;
    
    return (
      <View style={styles.achievementCard}>
        <View style={styles.achievementHeader}>
          <View style={[styles.achievementIcon, { backgroundColor: achievement.color + '20' }]}>
            <achievement.icon size={24} color={achievement.color} />
          </View>
          <View style={styles.achievementInfo}>
            <Text style={styles.achievementTitle}>{achievement.title}</Text>
            <Text style={styles.achievementDescription}>{achievement.description}</Text>
          </View>
          {achievement.completed && (
            <View style={styles.completedBadge}>
              <Trophy size={16} color="#F59E0B" />
            </View>
          )}
        </View>
        
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View 
              style={[
                styles.progressFill, 
                { width: `${Math.min(progressPercentage, 100)}%`, backgroundColor: achievement.color }
              ]} 
            />
          </View>
          <Text style={styles.progressText}>
            {typeof achievement.progress === 'number' && achievement.progress > 1000 
              ? `₹${achievement.progress.toLocaleString()} / ₹${achievement.target.toLocaleString()}`
              : `${achievement.progress} / ${achievement.target}`
            }
          </Text>
        </View>
        
        <View style={styles.rewardContainer}>
          <Gift size={16} color="#6B7280" />
          <Text style={styles.rewardReward}>{achievement.reward}</Text>
        </View>
      </View>
    );
  };

  if (!user) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.errorContainer}>
          <Award size={48} color="#9CA3AF" />
          <Text style={styles.errorTitle}>Sign In Required</Text>
          <Text style={styles.errorText}>Please sign in to view your blockchain rewards and achievements</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient
        colors={['#8B5CF6', '#3B82F6']}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.headerTitle}>Your Rewards</Text>
            <Text style={styles.headerSubtitle}>Blockchain-powered achievements</Text>
          </View>
          <View style={styles.headerActions}>
            <View style={styles.tokenCounter}>
              <Award size={20} color="white" />
              <Text style={styles.tokenCount}>{rewards.length}</Text>
            </View>
            <TouchableOpacity 
              style={[
                styles.sparklesButton,
                checkingBadges && styles.sparklesButtonActive
              ]}
              onPress={showAIFeatures}
              disabled={checkingBadges}
              activeOpacity={0.7}
            >
              {checkingBadges ? (
                <ActivityIndicator size={20} color="white" />
              ) : (
                <Sparkles size={20} color="white" />
              )}
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>

      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'rewards' && styles.activeTab]}
          onPress={() => setSelectedTab('rewards')}
          activeOpacity={0.8}
        >
          <Text style={[styles.tabText, selectedTab === 'rewards' && styles.activeTabText]}>
            Earned Rewards
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'achievements' && styles.activeTab]}
          onPress={() => setSelectedTab('achievements')}
          activeOpacity={0.8}
        >
          <Text style={[styles.tabText, selectedTab === 'achievements' && styles.activeTabText]}>
            Achievements
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView 
        style={styles.scrollView} 
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={true}
        indicatorStyle="default"
        scrollIndicatorInsets={{ right: 1 }}
        bounces={true}
        alwaysBounceVertical={true}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {selectedTab === 'rewards' ? (
          <View style={styles.rewardsGrid}>
            {loading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#8B5CF6" />
                <Text style={styles.loadingText}>Loading your rewards...</Text>
              </View>
            ) : rewards.length > 0 ? (
              rewards.map((reward) => (
                <RewardCard key={reward.id} reward={reward} />
              ))
            ) : (
              <View style={styles.emptyState}>
                <Award size={48} color="#9CA3AF" />
                <Text style={styles.emptyTitle}>No Rewards Yet</Text>
                <Text style={styles.emptyDescription}>
                  Save ₹1000 or more in a month to earn your first blockchain badge!
                </Text>
                <TouchableOpacity 
                  style={[
                    styles.checkButton,
                    checkingBadges && styles.checkButtonDisabled
                  ]}
                  onPress={checkForNewBadges}
                  disabled={checkingBadges}
                  activeOpacity={0.8}
                >
                  {checkingBadges ? (
                    <ActivityIndicator size={16} color="white" />
                  ) : (
                    <Sparkles size={16} color="white" />
                  )}
                  <Text style={styles.checkButtonText}>
                    {checkingBadges ? 'Checking...' : 'Check for New Badges'}
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        ) : (
          <View style={styles.achievementsList}>
            {achievements.map((achievement) => (
              <AchievementCard key={achievement.id} achievement={achievement} />
            ))}
          </View>
        )}
        
        <View style={styles.infoSection}>
          <View style={styles.infoCard}>
            <View style={styles.infoHeader}>
              <Shield size={24} color="#14B8A6" />
              <Text style={styles.infoTitle}>Blockchain Security</Text>
            </View>
            <Text style={styles.infoText}>
              Your rewards are secured on the Algorand blockchain. Each achievement token is unique, 
              non-transferable, and permanently yours. View your tokens on the Algorand explorer 
              by tapping on any reward card.
            </Text>
          </View>
          
          <View style={styles.infoCard}>
            <View style={styles.infoHeader}>
              <Target size={24} color="#8B5CF6" />
              <Text style={styles.infoTitle}>How to Earn More</Text>
            </View>
            <Text style={styles.infoText}>
              Save ₹1000+ monthly to earn badges automatically. Different savings amounts unlock 
              different rarities: Common (₹1000+), Rare (₹2500+), Epic (₹5000+), Legendary (₹10000+).
            </Text>
          </View>

          <View style={styles.infoCard}>
            <View style={styles.infoHeader}>
              <Sparkles size={24} color="#F59E0B" />
              <Text style={styles.infoTitle}>AI Badge System</Text>
            </View>
            <Text style={styles.infoText}>
              Our AI automatically analyzes your savings and awards badges based on your monthly performance. 
              Each badge is unique and stored permanently on the blockchain. The more you save, the rarer your badges become!
            </Text>
          </View>
        </View>

        {/* Extra spacing at bottom for better scrolling */}
        <View style={styles.bottomSpacing} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  errorTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginTop: 16,
    marginBottom: 8,
  },
  errorText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  header: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: 'white',
  },
  headerSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255, 255, 255, 0.8)',
    marginTop: 4,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  tokenCounter: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  tokenCount: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: 'white',
    marginLeft: 8,
  },
  sparklesButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  sparklesButtonActive: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderColor: 'rgba(255, 255, 255, 0.5)',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#E5E7EB',
    borderRadius: 12,
    margin: 24,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  activeTabText: {
    color: '#8B5CF6',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingBottom: 120,
  },
  rewardsGrid: {
    gap: 16,
    marginBottom: 24,
  },
  loadingContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  loadingText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 16,
  },
  rewardCard: {
    borderRadius: 16,
    borderWidth: 2,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  rewardGradient: {
    padding: 20,
  },
  rewardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  rewardIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rarityBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  rarityText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  rewardTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  rewardDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 20,
    marginBottom: 16,
  },
  rewardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  rewardInfo: {
    flex: 1,
  },
  rewardAmount: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#16A34A',
  },
  rewardMonth: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginTop: 2,
  },
  tokenInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  tokenId: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
    backgroundColor: 'white',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
    paddingHorizontal: 20,
  },
  checkButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#8B5CF6',
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 12,
    gap: 8,
  },
  checkButtonDisabled: {
    opacity: 0.7,
  },
  checkButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  achievementsList: {
    gap: 16,
    marginBottom: 24,
  },
  achievementCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  achievementHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  achievementIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  achievementInfo: {
    flex: 1,
  },
  achievementTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  achievementDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 4,
    lineHeight: 20,
  },
  completedBadge: {
    padding: 8,
  },
  progressContainer: {
    marginBottom: 12,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#E5E7EB',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    textAlign: 'center',
  },
  rewardContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  rewardReward: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 8,
  },
  infoSection: {
    gap: 16,
    marginBottom: 24,
  },
  infoCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  infoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginLeft: 12,
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 20,
  },
  bottomSpacing: {
    height: 40,
  },
});
import { supabase } from './supabase';

export interface BadgeReward {
  id: string;
  tokenId: string;
  rewardType: string;
  amountSaved: number;
  month: string;
  rarity: string;
  createdAt: string;
}

export const rewardsService = {
  /**
   * Check if user qualifies for a monthly savings badge and mint one if they do
   */
  async checkAndMintSavingsBadge(userId: string, month?: string): Promise<{ success: boolean; badge?: BadgeReward; message: string }> {
    try {
      console.log('Checking savings badge for user:', userId);
      
      // For demo purposes, simulate checking savings and potentially awarding a badge
      const currentMonth = new Date().toLocaleString('default', { month: 'long', year: 'numeric' });
      const targetMonth = month || currentMonth;
      
      // Check if badge already exists for this month
      const { data: existingBadge, error: checkError } = await supabase
        .from('blockchain_rewards')
        .select('id')
        .eq('user_id', userId)
        .eq('month', targetMonth)
        .single();

      if (checkError && checkError.code !== 'PGRST116') {
        console.error('Error checking existing badge:', checkError);
        return { success: false, message: 'Failed to check existing badges' };
      }

      if (existingBadge) {
        return { 
          success: false, 
          message: `You already have a badge for ${targetMonth}! Keep saving to earn next month's badge.` 
        };
      }

      // Simulate savings calculation (in a real app, this would calculate actual savings)
      const simulatedSavings = Math.floor(Math.random() * 15000) + 1000; // Random savings between 1000-16000
      
      if (simulatedSavings < 1000) {
        return {
          success: false,
          message: `You saved ₹${simulatedSavings.toLocaleString()} this month. Save ₹1000 or more to earn a badge!`
        };
      }

      // Determine badge type based on savings
      const badgeInfo = this.determineBadgeType(simulatedSavings);
      const tokenId = this.generateTokenId(userId, targetMonth);

      // Create the badge in database
      const { data: newBadge, error: insertError } = await supabase
        .from('blockchain_rewards')
        .insert({
          user_id: userId,
          token_id: tokenId,
          reward_type: badgeInfo.type,
          amount_saved: simulatedSavings,
          month: targetMonth,
        })
        .select()
        .single();

      if (insertError) {
        console.error('Error creating badge:', insertError);
        return { success: false, message: 'Failed to create badge' };
      }

      const badge: BadgeReward = {
        id: newBadge.id,
        tokenId: newBadge.token_id,
        rewardType: newBadge.reward_type,
        amountSaved: newBadge.amount_saved,
        month: newBadge.month,
        rarity: badgeInfo.rarity,
        createdAt: newBadge.created_at,
      };

      return {
        success: true,
        badge,
        message: `🎉 Congratulations! You earned a ${badgeInfo.rarity} ${badgeInfo.type} for saving ₹${simulatedSavings.toLocaleString()} in ${targetMonth}!`
      };

    } catch (error) {
      console.error('Error in checkAndMintSavingsBadge:', error);
      return { success: false, message: 'An error occurred while checking badge eligibility' };
    }
  },

  /**
   * Get all rewards for a user
   */
  async getUserRewards(userId: string): Promise<BadgeReward[]> {
    try {
      const { data, error } = await supabase
        .from('blockchain_rewards')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching user rewards:', error);
        return [];
      }

      return data.map(reward => ({
        id: reward.id,
        tokenId: reward.token_id,
        rewardType: reward.reward_type,
        amountSaved: reward.amount_saved,
        month: reward.month,
        rarity: this.getRarityFromSavings(reward.amount_saved),
        createdAt: reward.created_at,
      }));
    } catch (error) {
      console.error('Error in getUserRewards:', error);
      return [];
    }
  },

  /**
   * Manually trigger badge check for current month
   */
  async triggerMonthlySavingsCheck(userId: string): Promise<{ success: boolean; message: string }> {
    try {
      console.log('Triggering monthly savings check for user:', userId);
      
      // Call the checkAndMintSavingsBadge function directly
      const result = await this.checkAndMintSavingsBadge(userId);
      
      return {
        success: result.success,
        message: result.message,
      };
    } catch (error) {
      console.error('Error in triggerMonthlySavingsCheck:', error);
      return { success: false, message: 'An error occurred during savings check' };
    }
  },

  /**
   * Determine badge type based on savings amount
   */
  determineBadgeType(savings: number): { type: string; rarity: string } {
    if (savings >= 10000) {
      return { type: 'Legendary Saver', rarity: 'Legendary' };
    } else if (savings >= 5000) {
      return { type: 'Epic Saver', rarity: 'Epic' };
    } else if (savings >= 2500) {
      return { type: 'Rare Saver', rarity: 'Rare' };
    } else {
      return { type: 'Saver Badge', rarity: 'Common' };
    }
  },

  /**
   * Generate unique token ID
   */
  generateTokenId(userId: string, month: string): string {
    const timestamp = Date.now();
    const hash = btoa(`${userId}-${month}-${timestamp}`).replace(/[^a-zA-Z0-9]/g, '').substring(0, 8);
    return `ALG${hash.toUpperCase()}`;
  },

  /**
   * Get rarity based on savings amount
   */
  getRarityFromSavings(savings: number): string {
    if (savings >= 10000) return 'Legendary';
    if (savings >= 5000) return 'Epic';
    if (savings >= 2500) return 'Rare';
    return 'Common';
  },

  /**
   * Get badge color based on rarity
   */
  getBadgeColor(rarity: string): string {
    switch (rarity) {
      case 'Legendary': return '#F59E0B';
      case 'Epic': return '#8B5CF6';
      case 'Rare': return '#3B82F6';
      case 'Common': return '#10B981';
      default: return '#6B7280';
    }
  },

  /**
   * Simulate monthly savings calculation
   */
  async calculateMonthlySavings(userId: string): Promise<number> {
    // In a real app, this would calculate actual savings from income/expense data
    // For demo purposes, return a random amount
    return Math.floor(Math.random() * 15000) + 500;
  },
};
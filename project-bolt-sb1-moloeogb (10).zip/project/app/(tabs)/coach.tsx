import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Platform,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Bot, Send, Mic, MicOff, Play, Pause, Volume2, VolumeX, MessageSquare, Sparkles } from 'lucide-react-native';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  hasAudio?: boolean;
}

export default function Coach() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm your personal finance coach. I'm here to help you make smarter financial decisions and reach your savings goals. How can I assist you today?",
      isUser: false,
      timestamp: new Date(),
      hasAudio: true,
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isAudioPlaying, setIsAudioPlaying] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);
  const recordingAnimation = useRef(new Animated.Value(1)).current;
  const sparklesAnimation = useRef(new Animated.Value(1)).current;

  const sendMessage = async (text: string, isVoice: boolean = false) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: text.trim(),
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    // Simulate API call to coach service
    setTimeout(() => {
      const coachResponse = generateCoachResponse(text);
      const coachMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: coachResponse.text,
        isUser: false,
        timestamp: new Date(),
        hasAudio: coachResponse.hasAudio,
      };

      setMessages(prev => [...prev, coachMessage]);
      setIsLoading(false);
    }, 1500);

    // Scroll to bottom
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const generateCoachResponse = (userText: string): { text: string; hasAudio: boolean } => {
    const lowerText = userText.toLowerCase();
    
    if (lowerText.includes('save') || lowerText.includes('saving')) {
      return {
        text: "Great question about saving! Based on your spending patterns, I recommend the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings. You're currently saving 18% - just 2% away from the goal! I can provide personalized strategies to help you reach that target.",
        hasAudio: true,
      };
    } else if (lowerText.includes('budget') || lowerText.includes('expense')) {
      return {
        text: "I've analyzed your recent expenses and noticed you're spending 15% more on dining out this month. Here's a tip: try meal prepping on Sundays - it can save you ₹3,000-4,000 monthly! I can create a personalized meal budget plan for you.",
        hasAudio: true,
      };
    } else if (lowerText.includes('goal') || lowerText.includes('target')) {
      return {
        text: "Setting financial goals is crucial! I see you're 60% towards your savings goal. To reach ₹2,000 by month-end, you need to save ₹400 more. I suggest cutting entertainment expenses by 20% and finding one subscription to pause.",
        hasAudio: true,
      };
    } else {
      return {
        text: "I understand your concern. Let me analyze your financial data and provide personalized advice. Based on your spending patterns, I can help you optimize your budget and reach your financial goals faster. What specific area would you like to focus on?",
        hasAudio: true,
      };
    }
  };

  const startVoiceRecording = () => {
    console.log('Voice recording button pressed');
    
    if (Platform.OS === 'web') {
      // Web implementation - simulate voice recording
      setIsRecording(true);
      
      // Start pulsing animation
      Animated.loop(
        Animated.sequence([
          Animated.timing(recordingAnimation, {
            toValue: 1.2,
            duration: 800,
            useNativeDriver: true,
          }),
          Animated.timing(recordingAnimation, {
            toValue: 1,
            duration: 800,
            useNativeDriver: true,
          }),
        ])
      ).start();

      Alert.alert(
        '🎤 Voice Recording Active',
        'Speak your question now. Recording will stop automatically in 5 seconds.',
        [
          { 
            text: 'Stop Recording', 
            onPress: () => stopVoiceRecording(),
            style: 'destructive'
          }
        ]
      );
      
      // Auto-stop after 5 seconds with sample question
      setTimeout(() => {
        if (isRecording) {
          stopVoiceRecording();
          sendMessage("How can I save more money this month?", true);
        }
      }, 5000);
    } else {
      // Mobile implementation would use expo-av or similar
      Alert.alert(
        'Voice Recording',
        'Voice recording feature will be available in the mobile app. For now, please type your message.',
        [{ text: 'OK' }]
      );
    }
  };

  const stopVoiceRecording = () => {
    console.log('Stopping voice recording');
    setIsRecording(false);
    recordingAnimation.stopAnimation();
    recordingAnimation.setValue(1);
  };

  const playAudio = (messageId: string) => {
    console.log('Audio button pressed for message:', messageId);
    
    if (isMuted) {
      Alert.alert('🔇 Audio Muted', 'Please unmute to hear audio responses.');
      return;
    }

    if (isAudioPlaying === messageId) {
      // Stop audio
      setIsAudioPlaying(null);
      Alert.alert('🔊 Audio Stopped', 'Audio playback has been stopped.');
    } else {
      // Start audio
      setIsAudioPlaying(messageId);
      Alert.alert(
        '🔊 Playing Audio Response',
        'Your AI coach is speaking the response with natural voice synthesis. This helps you understand complex financial concepts while multitasking.\n\n🎵 Audio features:\n• Natural voice synthesis\n• Clear pronunciation\n• Adjustable playback speed\n• Background playback support',
        [
          { 
            text: 'Stop Audio', 
            onPress: () => setIsAudioPlaying(null),
            style: 'destructive'
          },
          { text: 'Continue Listening', style: 'default' }
        ]
      );
      
      // Auto-stop audio after 8 seconds
      setTimeout(() => {
        if (isAudioPlaying === messageId) {
          setIsAudioPlaying(null);
        }
      }, 8000);
    }
  };

  const toggleAudio = () => {
    console.log('Audio toggle button pressed');
    
    const newMutedState = !isMuted;
    setIsMuted(newMutedState);
    
    if (newMutedState) {
      // Muting - stop any playing audio
      setIsAudioPlaying(null);
      Alert.alert(
        '🔇 Audio Muted', 
        'All audio responses have been muted. You can still read text responses.',
        [{ text: 'OK' }]
      );
    } else {
      Alert.alert(
        '🔊 Audio Enabled', 
        'Audio is now enabled! You can hear voice responses from your AI coach.',
        [{ text: 'Great!' }]
      );
    }
  };

  const showAIFeatures = () => {
    console.log('AI Features button pressed');
    
    // Start sparkles animation
    Animated.sequence([
      Animated.timing(sparklesAnimation, {
        toValue: 1.3,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(sparklesAnimation, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start();

    Alert.alert(
      '✨ AI Features Overview',
      'Your personal finance coach uses cutting-edge AI technology:\n\n🧠 Machine Learning:\n• Analyzes your spending patterns\n• Predicts future expenses\n• Suggests personalized savings strategies\n\n🎤 Voice Interaction:\n• Natural language processing\n• Voice-to-text conversion\n• Audio response generation\n\n📊 Smart Analytics:\n• Real-time budget analysis\n• Goal progress tracking\n• Automated insights',
      [
        { 
          text: 'Technical Details', 
          onPress: () => {
            Alert.alert(
              '🔬 AI Technology Stack',
              'Our AI coach is powered by:\n\n• Advanced NLP models for understanding\n• Predictive algorithms for forecasting\n• Personalization engines for custom advice\n• Real-time data processing\n• Secure cloud infrastructure\n\nAll processing is secure and private!',
              [
                { text: 'Privacy Info', onPress: () => {
                  Alert.alert(
                    '🔒 Privacy & Security',
                    'Your data is protected with:\n\n• End-to-end encryption\n• Local processing when possible\n• No data sharing with third parties\n• GDPR compliant\n• Regular security audits\n• You control your data'
                  );
                }},
                { text: 'Got It!', style: 'default' }
              ]
            );
          }
        },
        { 
          text: 'Try Features', 
          onPress: () => {
            Alert.alert(
              '🚀 Try AI Features',
              'Ready to experience the power of AI coaching?\n\n• Ask about your spending patterns\n• Request a savings strategy\n• Get budget recommendations\n• Set financial goals\n\nJust type your question below!'
            );
          }
        },
        { text: 'Awesome!', style: 'default' }
      ]
    );
  };

  const MessageBubble = ({ message }: { message: Message }) => (
    <View style={[
      styles.messageBubble,
      message.isUser ? styles.userMessage : styles.coachMessage
    ]}>
      {!message.isUser && (
        <View style={styles.coachAvatar}>
          <Bot size={16} color="white" />
        </View>
      )}
      
      <View style={[
        styles.messageContent,
        message.isUser ? styles.userContent : styles.coachContent
      ]}>
        <Text style={[
          styles.messageText,
          message.isUser ? styles.userText : styles.coachText
        ]}>
          {message.text}
        </Text>
        
        {message.hasAudio && (
          <TouchableOpacity 
            style={[
              styles.audioButton,
              isAudioPlaying === message.id && styles.audioButtonActive
            ]}
            onPress={() => playAudio(message.id)}
            activeOpacity={0.8}
          >
            {isAudioPlaying === message.id ? (
              <Pause size={16} color="#EF4444" />
            ) : (
              <Play size={16} color="#6B7280" />
            )}
            <Text style={[
              styles.audioText,
              isAudioPlaying === message.id && styles.audioTextActive
            ]}>
              {isAudioPlaying === message.id ? 'Stop Audio' : 'Play Audio'}
            </Text>
          </TouchableOpacity>
        )}
        
        <Text style={styles.timestamp}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient
        colors={['#14B8A6', '#3B82F6']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <View style={styles.coachInfo}>
            <View style={styles.coachIcon}>
              <Bot size={24} color="white" />
            </View>
            <View>
              <Text style={styles.coachName}>AI Finance Coach</Text>
              <Text style={styles.coachStatus}>
                {isMuted ? '🔇 Muted' : '🔊 Audio On'} • Ready to help
              </Text>
            </View>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity 
              style={[
                styles.headerButton,
                isMuted && styles.headerButtonMuted
              ]} 
              onPress={toggleAudio}
              activeOpacity={0.7}
            >
              {isMuted ? <VolumeX size={20} color="white" /> : <Volume2 size={20} color="white" />}
            </TouchableOpacity>
            <Animated.View style={{ transform: [{ scale: sparklesAnimation }] }}>
              <TouchableOpacity 
                style={styles.headerButton}
                onPress={showAIFeatures}
                activeOpacity={0.7}
              >
                <Sparkles size={20} color="white" />
              </TouchableOpacity>
            </Animated.View>
          </View>
        </View>
      </LinearGradient>

      <ScrollView
        ref={scrollViewRef}
        style={styles.chatContainer}
        contentContainerStyle={styles.chatContent}
        showsVerticalScrollIndicator={true}
        indicatorStyle="default"
        scrollIndicatorInsets={{ right: 1 }}
        bounces={true}
        alwaysBounceVertical={true}
      >
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
        
        {isLoading && (
          <View style={styles.loadingContainer}>
            <View style={styles.coachAvatar}>
              <Bot size={16} color="white" />
            </View>
            <View style={styles.loadingBubble}>
              <View style={styles.typingIndicator}>
                <View style={styles.dot} />
                <View style={styles.dot} />
                <View style={styles.dot} />
              </View>
            </View>
          </View>
        )}

        {/* Extra spacing at bottom for better scrolling */}
        <View style={styles.bottomSpacing} />
      </ScrollView>

      <SafeAreaView edges={['bottom']}>
        <View style={styles.inputContainer}>
          <View style={styles.inputRow}>
            <TextInput
              style={styles.textInput}
              placeholder="Ask your finance coach anything..."
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
              placeholderTextColor="#9CA3AF"
            />
            <TouchableOpacity
              style={styles.sendButton}
              onPress={() => sendMessage(inputText)}
              disabled={!inputText.trim() || isLoading}
              activeOpacity={0.8}
            >
              <Send size={20} color={inputText.trim() ? "#14B8A6" : "#9CA3AF"} />
            </TouchableOpacity>
          </View>
          
          <View style={styles.quickActions}>
            <Animated.View style={{ transform: [{ scale: recordingAnimation }] }}>
              <TouchableOpacity
                style={[
                  styles.voiceButton, 
                  isRecording && styles.recording
                ]}
                onPress={isRecording ? stopVoiceRecording : startVoiceRecording}
                activeOpacity={0.8}
              >
                {isRecording ? <MicOff size={20} color="white" /> : <Mic size={20} color="#14B8A6" />}
                <Text style={[styles.actionText, isRecording && styles.recordingText]}>
                  {isRecording ? 'Recording...' : 'Voice'}
                </Text>
              </TouchableOpacity>
            </Animated.View>
            
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={() => sendMessage("How can I save more money this month?")}
              activeOpacity={0.8}
            >
              <MessageSquare size={16} color="#6B7280" />
              <Text style={styles.quickActionText}>Save Money</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={() => sendMessage("Analyze my spending patterns")}
              activeOpacity={0.8}
            >
              <MessageSquare size={16} color="#6B7280" />
              <Text style={styles.quickActionText}>Spending Analysis</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingHorizontal: 24,
    paddingBottom: 16,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  coachInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  coachIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  coachName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  coachStatus: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255, 255, 255, 0.8)',
    marginTop: 2,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  headerButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  headerButtonMuted: {
    backgroundColor: 'rgba(239, 68, 68, 0.3)',
    borderColor: 'rgba(239, 68, 68, 0.5)',
  },
  chatContainer: {
    flex: 1,
  },
  chatContent: {
    padding: 24,
    paddingBottom: 120,
  },
  messageBubble: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-end',
  },
  userMessage: {
    justifyContent: 'flex-end',
  },
  coachMessage: {
    justifyContent: 'flex-start',
  },
  coachAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#14B8A6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
    marginBottom: 4,
  },
  messageContent: {
    maxWidth: '75%',
    borderRadius: 16,
    padding: 12,
  },
  userContent: {
    backgroundColor: '#14B8A6',
    borderBottomRightRadius: 4,
  },
  coachContent: {
    backgroundColor: 'white',
    borderBottomLeftRadius: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  messageText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    lineHeight: 20,
  },
  userText: {
    color: 'white',
  },
  coachText: {
    color: '#1F2937',
  },
  audioButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
    padding: 8,
    marginTop: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  audioButtonActive: {
    backgroundColor: '#FEE2E2',
    borderColor: '#EF4444',
  },
  audioText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
  audioTextActive: {
    color: '#EF4444',
  },
  timestamp: {
    fontSize: 10,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    marginTop: 4,
    textAlign: 'right',
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 16,
  },
  loadingBubble: {
    backgroundColor: 'white',
    borderRadius: 16,
    borderBottomLeftRadius: 4,
    padding: 16,
    marginLeft: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  typingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#9CA3AF',
  },
  inputContainer: {
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 16,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: '#F9FAFB',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginBottom: 12,
  },
  textInput: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
    maxHeight: 100,
    paddingTop: 8,
    paddingBottom: 8,
  },
  sendButton: {
    padding: 8,
    marginLeft: 8,
  },
  quickActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  voiceButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0FDF4',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#14B8A6',
  },
  recording: {
    backgroundColor: '#EF4444',
    borderColor: '#EF4444',
  },
  actionText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#14B8A6',
    marginLeft: 4,
  },
  recordingText: {
    color: 'white',
  },
  quickActionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 16,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  quickActionText: {
    fontSize: 11,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
  bottomSpacing: {
    height: 40,
  },
});
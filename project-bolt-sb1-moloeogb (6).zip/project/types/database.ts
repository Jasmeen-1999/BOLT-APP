export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          avatar_url: string | null;
          is_premium: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          email: string;
          full_name?: string | null;
          avatar_url?: string | null;
          is_premium?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          avatar_url?: string | null;
          is_premium?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      expenses: {
        Row: {
          id: string;
          user_id: string;
          amount: number;
          category: string;
          description: string | null;
          date: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          amount: number;
          category: string;
          description?: string | null;
          date: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          amount?: number;
          category?: string;
          description?: string | null;
          date?: string;
          created_at?: string;
        };
      };
      income: {
        Row: {
          id: string;
          user_id: string;
          amount: number;
          source: string;
          description: string | null;
          date: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          amount: number;
          source: string;
          description?: string | null;
          date: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          amount?: number;
          source?: string;
          description?: string | null;
          date?: string;
          created_at?: string;
        };
      };
      blockchain_rewards: {
        Row: {
          id: string;
          user_id: string;
          token_id: string;
          reward_type: string;
          amount_saved: number;
          month: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          token_id: string;
          reward_type: string;
          amount_saved: number;
          month: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          token_id?: string;
          reward_type?: string;
          amount_saved?: number;
          month?: string;
          created_at?: string;
        };
      };
    };
  };
}
import React, { createContext, useContext, useState, useEffect } from 'react';

interface FinancialData {
  totalIncome: number;
  totalExpenses: number;
  balance: number;
  monthlyChange: number;
  savingsGoal: number;
  savingsProgress: number;
}

interface FinanceContextType {
  financialData: FinancialData;
  updateFinancialData: (data: Partial<FinancialData>) => void;
  addIncome: (amount: number) => void;
  addExpense: (amount: number) => void;
  setSavingsGoal: (goal: number) => void;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

export function useFinance() {
  const context = useContext(FinanceContext);
  if (context === undefined) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
}

export function FinanceProvider({ children }: { children: React.ReactNode }) {
  const [financialData, setFinancialData] = useState<FinancialData>({
    totalIncome: 5000,
    totalExpenses: 3200,
    balance: 1800,
    monthlyChange: 12.5,
    savingsGoal: 2000,
    savingsProgress: 60,
  });

  const updateFinancialData = (data: Partial<FinancialData>) => {
    setFinancialData(prev => {
      const updated = { ...prev, ...data };
      // Recalculate savings progress when goal or balance changes
      if (data.savingsGoal !== undefined || data.balance !== undefined) {
        updated.savingsProgress = Math.round((updated.balance / updated.savingsGoal) * 100);
      }
      return updated;
    });
  };

  const addIncome = (amount: number) => {
    setFinancialData(prev => {
      const updated = {
        ...prev,
        totalIncome: prev.totalIncome + amount,
        balance: prev.balance + amount,
      };
      updated.savingsProgress = Math.round((updated.balance / updated.savingsGoal) * 100);
      return updated;
    });
  };

  const addExpense = (amount: number) => {
    setFinancialData(prev => {
      const updated = {
        ...prev,
        totalExpenses: prev.totalExpenses + amount,
        balance: prev.balance - amount,
      };
      updated.savingsProgress = Math.round((updated.balance / updated.savingsGoal) * 100);
      return updated;
    });
  };

  const setSavingsGoal = (goal: number) => {
    setFinancialData(prev => ({
      ...prev,
      savingsGoal: goal,
      savingsProgress: Math.round((prev.balance / goal) * 100),
    }));
  };

  return (
    <FinanceContext.Provider value={{
      financialData,
      updateFinancialData,
      addIncome,
      addExpense,
      setSavingsGoal,
    }}>
      {children}
    </FinanceContext.Provider>
  );
}
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '@/contexts/AuthContext';
import { router } from 'expo-router';
import { User, Settings, Bell, Shield, CreditCard, Crown, CircleHelp as HelpCircle, LogOut, ChevronRight, Mail, Smartphone, Globe, Star, Award, Calendar } from 'lucide-react-native';

export default function Profile() {
  const { user, signOut } = useAuth();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [emailUpdates, setEmailUpdates] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  const handleSignOut = async () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign Out', style: 'destructive', onPress: async () => {
          await signOut();
          router.replace('/(auth)/sign-in');
        }},
      ]
    );
  };

  const upgradeToPremium = () => {
    Alert.alert(
      'Upgrade to Premium',
      'Get advanced analytics, unlimited AI coaching, and exclusive blockchain rewards!',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Upgrade', onPress: () => {
          // Implement RevenueCat subscription
          Alert.alert('Coming Soon', 'Premium subscription will be available soon!');
        }},
      ]
    );
  };

  const ProfileSection = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.sectionContent}>
        {children}
      </View>
    </View>
  );

  const ProfileRow = ({ 
    icon: Icon, 
    title, 
    subtitle, 
    onPress, 
    showChevron = true,
    rightElement
  }: {
    icon: any;
    title: string;
    subtitle?: string;
    onPress?: () => void;
    showChevron?: boolean;
    rightElement?: React.ReactNode;
  }) => (
    <TouchableOpacity style={styles.profileRow} onPress={onPress} disabled={!onPress}>
      <View style={styles.rowLeft}>
        <View style={styles.rowIcon}>
          <Icon size={20} color="#6B7280" />
        </View>
        <View style={styles.rowContent}>
          <Text style={styles.rowTitle}>{title}</Text>
          {subtitle && <Text style={styles.rowSubtitle}>{subtitle}</Text>}
        </View>
      </View>
      <View style={styles.rowRight}>
        {rightElement}
        {showChevron && <ChevronRight size={16} color="#9CA3AF" />}
      </View>
    </TouchableOpacity>
  );

  if (!user) {
    return null;
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {(user.full_name || user.email)?.[0]?.toUpperCase()}
            </Text>
          </View>
          {user.is_premium && (
            <View style={styles.premiumBadge}>
              <Crown size={12} color="#F59E0B" />
            </View>
          )}
        </View>
        <Text style={styles.userName}>{user.full_name || 'User'}</Text>
        <Text style={styles.userEmail}>{user.email}</Text>
        
        {!user.is_premium && (
          <TouchableOpacity style={styles.upgradeButton} onPress={upgradeToPremium}>
            <Crown size={16} color="white" />
            <Text style={styles.upgradeText}>Upgrade to Premium</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView 
        style={styles.scrollView} 
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <ProfileSection title="Account">
          <ProfileRow
            icon={User}
            title="Personal Information"
            subtitle="Name, email, and profile settings"
            onPress={() => Alert.alert('Coming Soon', 'Profile editing will be available soon!')}
          />
          <ProfileRow
            icon={CreditCard}
            title="Payment Methods"
            subtitle="Manage your payment options"
            onPress={() => Alert.alert('Coming Soon', 'Payment management will be available soon!')}
          />
          <ProfileRow
            icon={Shield}
            title="Privacy & Security"
            subtitle="Password, two-factor authentication"
            onPress={() => Alert.alert('Coming Soon', 'Security settings will be available soon!')}
          />
        </ProfileSection>

        <ProfileSection title="Preferences">
          <ProfileRow
            icon={Bell}
            title="Push Notifications"
            subtitle="Get notified about your financial goals"
            showChevron={false}
            rightElement={
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
                trackColor={{ false: '#E5E7EB', true: '#14B8A6' }}
                thumbColor={notificationsEnabled ? '#ffffff' : '#ffffff'}
              />
            }
          />
          <ProfileRow
            icon={Mail}
            title="Email Updates"
            subtitle="Weekly financial summaries and tips"
            showChevron={false}
            rightElement={
              <Switch
                value={emailUpdates}
                onValueChange={setEmailUpdates}
                trackColor={{ false: '#E5E7EB', true: '#14B8A6' }}
                thumbColor={emailUpdates ? '#ffffff' : '#ffffff'}
              />
            }
          />
          <ProfileRow
            icon={Globe}
            title="Language & Region"
            subtitle="English (India)"
            onPress={() => Alert.alert('Coming Soon', 'Language settings will be available soon!')}
          />
        </ProfileSection>

        <ProfileSection title="Premium Features">
          <ProfileRow
            icon={Star}
            title="Advanced Analytics"
            subtitle={user.is_premium ? "View detailed reports" : "Unlock with Premium"}
            onPress={() => user.is_premium ? 
              Alert.alert('Analytics', 'Advanced analytics coming soon!') : 
              upgradeToPremium()
            }
          />
          <ProfileRow
            icon={Award}
            title="Exclusive Rewards"
            subtitle={user.is_premium ? "Access premium blockchain rewards" : "Upgrade to unlock"}
            onPress={() => user.is_premium ? 
              router.push('/(tabs)/rewards') : 
              upgradeToPremium()
            }
          />
          <ProfileRow
            icon={Calendar}
            title="Custom Goals"
            subtitle={user.is_premium ? "Set unlimited financial goals" : "Premium feature"}
            onPress={() => user.is_premium ? 
              Alert.alert('Goals', 'Custom goals coming soon!') : 
              upgradeToPremium()
            }
          />
        </ProfileSection>

        <ProfileSection title="Support">
          <ProfileRow
            icon={HelpCircle}
            title="Help & Support"
            subtitle="Get help with your account"
            onPress={() => Alert.alert('Support', 'Contact support at support@financecoach.app')}
          />
          <ProfileRow
            icon={Smartphone}
            title="App Version"
            subtitle="Version 1.0.0"
            showChevron={false}
          />
        </ProfileSection>

        <View style={styles.dangerSection}>
          <TouchableOpacity style={styles.signOutButton} onPress={handleSignOut}>
            <LogOut size={20} color="#EF4444" />
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Made with ❤️ for better financial health
          </Text>
          <Text style={styles.footerVersion}>
            Personal Finance Coach v1.0.0
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 100,
  },
  header: {
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 32,
    paddingBottom: 32,
    backgroundColor: 'white',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#14B8A6',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  avatarText: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: 'white',
  },
  premiumBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FEF3C7',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'white',
  },
  userName: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 16,
  },
  upgradeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F59E0B',
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  upgradeText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
    marginLeft: 8,
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  sectionContent: {
    backgroundColor: 'white',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  rowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  rowIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  rowContent: {
    flex: 1,
  },
  rowTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
  },
  rowSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 2,
  },
  rowRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  dangerSection: {
    paddingHorizontal: 24,
    marginTop: 24,
  },
  signOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    borderRadius: 16,
    paddingVertical: 16,
    borderWidth: 1,
    borderColor: '#FEE2E2',
  },
  signOutText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#EF4444',
    marginLeft: 8,
  },
  footer: {
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 32,
    paddingBottom: 24,
  },
  footerText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 8,
  },
  footerVersion: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
  },
});
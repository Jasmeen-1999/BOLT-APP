import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Modal,
  Alert,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { PieChart, BarChart } from 'react-native-chart-kit';
import { useFinance } from '@/contexts/FinanceContext';
import { Calendar, Filter, TrendingUp, ShoppingCart, Car, Chrome as Home, Coffee, Heart, Smartphone, X, Check, CreditCard as Edit, Save, Plus, Minus, CalendarDays, Target, Clock, DollarSign } from 'lucide-react-native';

const screenWidth = Dimensions.get('window').width;

interface BudgetCategory {
  name: string;
  spent: number;
  budget: number;
  dailyLimit: number;
  todaySpent: number;
  color: string;
  icon: any;
}

interface DailyBudget {
  totalDailyBudget: number;
  todaySpent: number;
  remainingToday: number;
  daysInMonth: number;
  daysPassed: number;
  daysRemaining: number;
  averageDailySpending: number;
  projectedMonthlySpending: number;
}

interface FilterOptions {
  timeRange: 'Week' | 'Month' | 'Year';
  categories: string[];
  sortBy: 'name' | 'spent' | 'budget' | 'percentage';
  showOverBudget: boolean;
}

interface EditBudgetModalProps {
  visible: boolean;
  category: BudgetCategory | null;
  onSave: (categoryName: string, newBudget: number, newDailyLimit: number) => void;
  onCancel: () => void;
}

export default function Budget() {
  const { financialData } = useFinance();
  const [selectedPeriod, setSelectedPeriod] = useState('Month');
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<BudgetCategory | null>(null);
  const [showDailyView, setShowDailyView] = useState(false);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    timeRange: 'Month',
    categories: ['Food', 'Transport', 'Shopping', 'Bills', 'Healthcare', 'Entertainment'],
    sortBy: 'name',
    showOverBudget: false,
  });

  const [categories, setCategories] = useState<BudgetCategory[]>([
    { name: 'Food', spent: 850, budget: 1000, dailyLimit: 33, todaySpent: 45, color: '#EF4444', icon: Coffee },
    { name: 'Transport', spent: 600, budget: 800, dailyLimit: 27, todaySpent: 25, color: '#F59E0B', icon: Car },
    { name: 'Shopping', spent: 450, budget: 500, dailyLimit: 17, todaySpent: 0, color: '#8B5CF6', icon: ShoppingCart },
    { name: 'Bills', spent: 1200, budget: 1200, dailyLimit: 40, todaySpent: 0, color: '#3B82F6', icon: Home },
    { name: 'Healthcare', spent: 200, budget: 400, dailyLimit: 13, todaySpent: 0, color: '#10B981', icon: Heart },
    { name: 'Entertainment', spent: 300, budget: 400, dailyLimit: 13, todaySpent: 15, color: '#F97316', icon: Smartphone },
  ]);

  const periods = ['Week', 'Month', 'Year'];
  const sortOptions = [
    { key: 'name', label: 'Name' },
    { key: 'spent', label: 'Amount Spent' },
    { key: 'budget', label: 'Budget Amount' },
    { key: 'percentage', label: 'Budget Usage %' },
  ];

  // Calculate daily budget data
  const calculateDailyBudget = (): DailyBudget => {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const daysPassed = today.getDate();
    const daysRemaining = daysInMonth - daysPassed;
    
    const totalMonthlyBudget = categories.reduce((sum, cat) => sum + cat.budget, 0);
    const totalDailyBudget = Math.round(totalMonthlyBudget / daysInMonth);
    const todaySpent = categories.reduce((sum, cat) => sum + cat.todaySpent, 0);
    const remainingToday = Math.max(0, totalDailyBudget - todaySpent);
    
    const totalSpent = categories.reduce((sum, cat) => sum + cat.spent, 0);
    const averageDailySpending = Math.round(totalSpent / daysPassed);
    const projectedMonthlySpending = Math.round(averageDailySpending * daysInMonth);
    
    return {
      totalDailyBudget,
      todaySpent,
      remainingToday,
      daysInMonth,
      daysPassed,
      daysRemaining,
      averageDailySpending,
      projectedMonthlySpending,
    };
  };

  const dailyBudget = calculateDailyBudget();

  const handleEditBudget = (category: BudgetCategory) => {
    setEditingCategory(category);
    setShowEditModal(true);
  };

  const handleSaveBudget = (categoryName: string, newBudget: number, newDailyLimit: number) => {
    setCategories(prev => 
      prev.map(cat => 
        cat.name === categoryName 
          ? { ...cat, budget: newBudget, dailyLimit: newDailyLimit }
          : cat
      )
    );
    setShowEditModal(false);
    setEditingCategory(null);
    Alert.alert(
      'Budget Updated! ✅',
      `${categoryName} budget: ₹${newBudget.toLocaleString()}\nDaily limit: ₹${newDailyLimit.toLocaleString()}`
    );
  };

  const handleFilterPress = () => {
    setShowFilterModal(true);
  };

  const applyFilters = () => {
    setSelectedPeriod(filterOptions.timeRange);
    setShowFilterModal(false);
    Alert.alert(
      'Filters Applied! ✅',
      `Time Range: ${filterOptions.timeRange}\nSort By: ${sortOptions.find(s => s.key === filterOptions.sortBy)?.label}\nCategories: ${filterOptions.categories.length} selected\nShow Over Budget Only: ${filterOptions.showOverBudget ? 'Yes' : 'No'}`
    );
  };

  const resetFilters = () => {
    setFilterOptions({
      timeRange: 'Month',
      categories: ['Food', 'Transport', 'Shopping', 'Bills', 'Healthcare', 'Entertainment'],
      sortBy: 'name',
      showOverBudget: false,
    });
    Alert.alert('Filters Reset', 'All filters have been reset to default values.');
  };

  const getFilteredCategories = () => {
    let filtered = categories.filter(cat => 
      filterOptions.categories.includes(cat.name)
    );

    if (filterOptions.showOverBudget) {
      filtered = filtered.filter(cat => cat.spent > cat.budget);
    }

    filtered.sort((a, b) => {
      switch (filterOptions.sortBy) {
        case 'spent':
          return b.spent - a.spent;
        case 'budget':
          return b.budget - a.budget;
        case 'percentage':
          return (b.spent / b.budget) - (a.spent / a.budget);
        default:
          return a.name.localeCompare(b.name);
      }
    });

    return filtered;
  };

  const filteredCategories = getFilteredCategories();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const EditBudgetModal = ({ visible, category, onSave, onCancel }: EditBudgetModalProps) => {
    const [budgetAmount, setBudgetAmount] = useState(category?.budget?.toString() || '');
    const [dailyLimit, setDailyLimit] = useState(category?.dailyLimit?.toString() || '');
    const [tempBudget, setTempBudget] = useState(category?.budget || 0);
    const [tempDaily, setTempDaily] = useState(category?.dailyLimit || 0);

    React.useEffect(() => {
      if (category) {
        setBudgetAmount(category.budget.toString());
        setDailyLimit(category.dailyLimit.toString());
        setTempBudget(category.budget);
        setTempDaily(category.dailyLimit);
      }
    }, [category]);

    const handleSave = () => {
      const budget = parseFloat(budgetAmount);
      const daily = parseFloat(dailyLimit);
      if (isNaN(budget) || budget <= 0 || isNaN(daily) || daily <= 0) {
        Alert.alert('Invalid Amount', 'Please enter valid amounts greater than 0.');
        return;
      }
      if (category) {
        onSave(category.name, budget, daily);
      }
    };

    const adjustBudget = (increment: number) => {
      const newAmount = Math.max(0, tempBudget + increment);
      setTempBudget(newAmount);
      setBudgetAmount(newAmount.toString());
      // Auto-calculate daily limit
      const suggestedDaily = Math.round(newAmount / 30);
      setTempDaily(suggestedDaily);
      setDailyLimit(suggestedDaily.toString());
    };

    const adjustDaily = (increment: number) => {
      const newAmount = Math.max(0, tempDaily + increment);
      setTempDaily(newAmount);
      setDailyLimit(newAmount.toString());
    };

    if (!category) return null;

    return (
      <Modal
        visible={visible}
        transparent
        animationType="slide"
        onRequestClose={onCancel}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.editModal}>
            <View style={styles.editModalHeader}>
              <View style={styles.editModalTitleRow}>
                <View style={[styles.editModalIcon, { backgroundColor: category.color + '20' }]}>
                  <category.icon size={24} color={category.color} />
                </View>
                <Text style={styles.editModalTitle}>Edit {category.name} Budget</Text>
              </View>
              <TouchableOpacity onPress={onCancel} style={styles.closeButton}>
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.editModalContent} showsVerticalScrollIndicator={false}>
              <View style={styles.currentBudgetInfo}>
                <Text style={styles.currentBudgetLabel}>Current Settings</Text>
                <Text style={styles.currentBudgetAmount}>Monthly: {formatCurrency(category.budget)}</Text>
                <Text style={styles.currentSpentAmount}>
                  Daily Limit: {formatCurrency(category.dailyLimit)} | Today: {formatCurrency(category.todaySpent)}
                </Text>
              </View>

              {/* Monthly Budget Section */}
              <View style={styles.budgetInputSection}>
                <Text style={styles.inputLabel}>Monthly Budget Amount</Text>
                <View style={styles.budgetInputContainer}>
                  <TouchableOpacity 
                    style={styles.adjustButton}
                    onPress={() => adjustBudget(-100)}
                  >
                    <Minus size={20} color="#6B7280" />
                  </TouchableOpacity>
                  
                  <TextInput
                    style={styles.budgetInput}
                    value={budgetAmount}
                    onChangeText={(text) => {
                      setBudgetAmount(text);
                      const amount = parseFloat(text);
                      if (!isNaN(amount)) {
                        setTempBudget(amount);
                        const suggestedDaily = Math.round(amount / 30);
                        setTempDaily(suggestedDaily);
                        setDailyLimit(suggestedDaily.toString());
                      }
                    }}
                    keyboardType="numeric"
                    placeholder="Enter amount"
                    placeholderTextColor="#9CA3AF"
                  />
                  
                  <TouchableOpacity 
                    style={styles.adjustButton}
                    onPress={() => adjustBudget(100)}
                  >
                    <Plus size={20} color="#6B7280" />
                  </TouchableOpacity>
                </View>
                
                <Text style={styles.previewAmount}>
                  Monthly: {formatCurrency(tempBudget)}
                </Text>
              </View>

              {/* Daily Limit Section */}
              <View style={styles.budgetInputSection}>
                <Text style={styles.inputLabel}>Daily Spending Limit</Text>
                <View style={styles.budgetInputContainer}>
                  <TouchableOpacity 
                    style={styles.adjustButton}
                    onPress={() => adjustDaily(-5)}
                  >
                    <Minus size={20} color="#6B7280" />
                  </TouchableOpacity>
                  
                  <TextInput
                    style={styles.budgetInput}
                    value={dailyLimit}
                    onChangeText={(text) => {
                      setDailyLimit(text);
                      const amount = parseFloat(text);
                      if (!isNaN(amount)) {
                        setTempDaily(amount);
                      }
                    }}
                    keyboardType="numeric"
                    placeholder="Enter daily limit"
                    placeholderTextColor="#9CA3AF"
                  />
                  
                  <TouchableOpacity 
                    style={styles.adjustButton}
                    onPress={() => adjustDaily(5)}
                  >
                    <Plus size={20} color="#6B7280" />
                  </TouchableOpacity>
                </View>
                
                <Text style={styles.previewAmount}>
                  Daily: {formatCurrency(tempDaily)}
                </Text>
              </View>

              <View style={styles.quickAmountSection}>
                <Text style={styles.quickAmountLabel}>Quick Monthly Budgets</Text>
                <View style={styles.quickAmountButtons}>
                  {[500, 1000, 2000, 5000, 10000].map((amount) => (
                    <TouchableOpacity
                      key={amount}
                      style={[
                        styles.quickAmountButton,
                        tempBudget === amount && styles.quickAmountButtonSelected
                      ]}
                      onPress={() => {
                        setTempBudget(amount);
                        setBudgetAmount(amount.toString());
                        const suggestedDaily = Math.round(amount / 30);
                        setTempDaily(suggestedDaily);
                        setDailyLimit(suggestedDaily.toString());
                      }}
                    >
                      <Text style={[
                        styles.quickAmountButtonText,
                        tempBudget === amount && styles.quickAmountButtonTextSelected
                      ]}>
                        ₹{amount.toLocaleString()}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.budgetTips}>
                <Text style={styles.budgetTipsTitle}>💡 Daily Budget Tips</Text>
                <Text style={styles.budgetTipsText}>
                  • Daily limits help control spending habits{'\n'}
                  • Aim for 80% of daily limit to build buffer{'\n'}
                  • Track daily expenses in real-time{'\n'}
                  • Unused daily budget can roll over to savings{'\n'}
                  • Review and adjust weekly based on patterns
                </Text>
              </View>
            </ScrollView>

            <View style={styles.editModalActions}>
              <TouchableOpacity style={styles.cancelButton} onPress={onCancel}>
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
                <Save size={16} color="white" />
                <Text style={styles.saveButtonText}>Save Budget</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };

  const DailyBudgetCard = () => (
    <View style={styles.dailyBudgetCard}>
      <View style={styles.dailyBudgetHeader}>
        <CalendarDays size={24} color="#14B8A6" />
        <Text style={styles.dailyBudgetTitle}>Today's Budget</Text>
        <TouchableOpacity 
          style={styles.dailyViewToggle}
          onPress={() => setShowDailyView(!showDailyView)}
        >
          <Text style={styles.dailyViewToggleText}>
            {showDailyView ? 'Hide Details' : 'View Details'}
          </Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.dailyBudgetStats}>
        <View style={styles.dailyBudgetItem}>
          <Text style={styles.dailyBudgetLabel}>Daily Budget</Text>
          <Text style={styles.dailyBudgetAmount}>{formatCurrency(dailyBudget.totalDailyBudget)}</Text>
        </View>
        <View style={styles.dailyBudgetDivider} />
        <View style={styles.dailyBudgetItem}>
          <Text style={styles.dailyBudgetLabel}>Spent Today</Text>
          <Text style={[styles.dailyBudgetAmount, { color: dailyBudget.todaySpent > dailyBudget.totalDailyBudget ? '#EF4444' : '#16A34A' }]}>
            {formatCurrency(dailyBudget.todaySpent)}
          </Text>
        </View>
        <View style={styles.dailyBudgetDivider} />
        <View style={styles.dailyBudgetItem}>
          <Text style={styles.dailyBudgetLabel}>Remaining</Text>
          <Text style={[styles.dailyBudgetAmount, { color: dailyBudget.remainingToday > 0 ? '#16A34A' : '#EF4444' }]}>
            {formatCurrency(dailyBudget.remainingToday)}
          </Text>
        </View>
      </View>

      <View style={styles.dailyProgress}>
        <View style={styles.dailyProgressBar}>
          <View 
            style={[
              styles.dailyProgressFill, 
              { 
                width: `${Math.min((dailyBudget.todaySpent / dailyBudget.totalDailyBudget) * 100, 100)}%`,
                backgroundColor: dailyBudget.todaySpent > dailyBudget.totalDailyBudget ? '#EF4444' : '#14B8A6'
              }
            ]} 
          />
        </View>
        <Text style={styles.dailyProgressText}>
          {Math.round((dailyBudget.todaySpent / dailyBudget.totalDailyBudget) * 100)}% of daily budget used
        </Text>
      </View>

      {showDailyView && (
        <View style={styles.dailyDetailsSection}>
          <View style={styles.dailyDetailRow}>
            <Clock size={16} color="#6B7280" />
            <Text style={styles.dailyDetailLabel}>Days in Month:</Text>
            <Text style={styles.dailyDetailValue}>{dailyBudget.daysInMonth}</Text>
          </View>
          <View style={styles.dailyDetailRow}>
            <Target size={16} color="#6B7280" />
            <Text style={styles.dailyDetailLabel}>Days Passed:</Text>
            <Text style={styles.dailyDetailValue}>{dailyBudget.daysPassed}</Text>
          </View>
          <View style={styles.dailyDetailRow}>
            <TrendingUp size={16} color="#6B7280" />
            <Text style={styles.dailyDetailLabel}>Avg Daily Spending:</Text>
            <Text style={styles.dailyDetailValue}>{formatCurrency(dailyBudget.averageDailySpending)}</Text>
          </View>
          <View style={styles.dailyDetailRow}>
            <DollarSign size={16} color="#6B7280" />
            <Text style={styles.dailyDetailLabel}>Projected Monthly:</Text>
            <Text style={[
              styles.dailyDetailValue,
              { color: dailyBudget.projectedMonthlySpending > categories.reduce((sum, cat) => sum + cat.budget, 0) ? '#EF4444' : '#16A34A' }
            ]}>
              {formatCurrency(dailyBudget.projectedMonthlySpending)}
            </Text>
          </View>
        </View>
      )}
    </View>
  );

  const CategoryCard = ({ category }: { category: BudgetCategory }) => {
    const percentage = (category.spent / category.budget) * 100;
    const dailyPercentage = (category.todaySpent / category.dailyLimit) * 100;
    const isOverBudget = percentage > 100;
    const isOverDailyLimit = dailyPercentage > 100;
    
    return (
      <View style={styles.categoryCard}>
        <View style={styles.categoryHeader}>
          <View style={[styles.categoryIcon, { backgroundColor: category.color + '20' }]}>
            <category.icon size={20} color={category.color} />
          </View>
          <View style={styles.categoryInfo}>
            <Text style={styles.categoryName}>{category.name}</Text>
            <Text style={styles.categoryAmount}>
              Monthly: {formatCurrency(category.spent)} / {formatCurrency(category.budget)}
            </Text>
            <Text style={styles.categoryDailyAmount}>
              Today: {formatCurrency(category.todaySpent)} / {formatCurrency(category.dailyLimit)}
            </Text>
          </View>
          <View style={styles.categoryActions}>
            <View style={[styles.percentageContainer, { backgroundColor: isOverBudget ? '#FEE2E2' : '#DCFCE7' }]}>
              <Text style={[styles.percentageText, { color: isOverBudget ? '#DC2626' : '#16A34A' }]}>
                {Math.round(percentage)}%
              </Text>
            </View>
            <TouchableOpacity 
              style={styles.editButton}
              onPress={() => handleEditBudget(category)}
              activeOpacity={0.7}
            >
              <Edit size={16} color="#6B7280" />
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Monthly Progress Bar */}
        <View style={styles.progressContainer}>
          <Text style={styles.progressLabel}>Monthly Progress</Text>
          <View style={styles.progressBar}>
            <View 
              style={[
                styles.progressFill, 
                { 
                  width: `${Math.min(percentage, 100)}%`,
                  backgroundColor: isOverBudget ? '#EF4444' : category.color
                }
              ]} 
            />
          </View>
        </View>

        {/* Daily Progress Bar */}
        <View style={styles.progressContainer}>
          <Text style={styles.progressLabel}>Daily Progress</Text>
          <View style={styles.progressBar}>
            <View 
              style={[
                styles.progressFill, 
                { 
                  width: `${Math.min(dailyPercentage, 100)}%`,
                  backgroundColor: isOverDailyLimit ? '#EF4444' : '#10B981'
                }
              ]} 
            />
          </View>
        </View>

        {(isOverBudget || isOverDailyLimit) && (
          <View style={styles.warningContainer}>
            <Text style={styles.warningText}>
              {isOverBudget && isOverDailyLimit ? '⚠️ Over monthly budget and daily limit!' :
               isOverBudget ? '⚠️ Over monthly budget!' : '⚠️ Over daily limit!'}
            </Text>
          </View>
        )}
      </View>
    );
  };

  const FilterModal = () => (
    <Modal
      visible={showFilterModal}
      transparent
      animationType="slide"
      onRequestClose={() => setShowFilterModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.filterModal}>
          <View style={styles.filterHeader}>
            <Text style={styles.filterTitle}>Filter & Sort</Text>
            <TouchableOpacity 
              onPress={() => setShowFilterModal(false)}
              style={styles.closeButton}
            >
              <X size={24} color="#6B7280" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.filterContent} showsVerticalScrollIndicator={false}>
            {/* Time Range */}
            <View style={styles.filterSection}>
              <Text style={styles.filterSectionTitle}>Time Range</Text>
              <View style={styles.filterOptions}>
                {periods.map((period) => (
                  <TouchableOpacity
                    key={period}
                    style={[
                      styles.filterOption,
                      filterOptions.timeRange === period && styles.filterOptionSelected
                    ]}
                    onPress={() => setFilterOptions(prev => ({ ...prev, timeRange: period as any }))}
                  >
                    <Text style={[
                      styles.filterOptionText,
                      filterOptions.timeRange === period && styles.filterOptionTextSelected
                    ]}>
                      {period}
                    </Text>
                    {filterOptions.timeRange === period && (
                      <Check size={16} color="#14B8A6" />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Sort By */}
            <View style={styles.filterSection}>
              <Text style={styles.filterSectionTitle}>Sort By</Text>
              <View style={styles.filterOptions}>
                {sortOptions.map((option) => (
                  <TouchableOpacity
                    key={option.key}
                    style={[
                      styles.filterOption,
                      filterOptions.sortBy === option.key && styles.filterOptionSelected
                    ]}
                    onPress={() => setFilterOptions(prev => ({ ...prev, sortBy: option.key as any }))}
                  >
                    <Text style={[
                      styles.filterOptionText,
                      filterOptions.sortBy === option.key && styles.filterOptionTextSelected
                    ]}>
                      {option.label}
                    </Text>
                    {filterOptions.sortBy === option.key && (
                      <Check size={16} color="#14B8A6" />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Categories */}
            <View style={styles.filterSection}>
              <Text style={styles.filterSectionTitle}>Categories</Text>
              <View style={styles.filterOptions}>
                {categories.map((category) => (
                  <TouchableOpacity
                    key={category.name}
                    style={[
                      styles.filterOption,
                      filterOptions.categories.includes(category.name) && styles.filterOptionSelected
                    ]}
                    onPress={() => {
                      setFilterOptions(prev => ({
                        ...prev,
                        categories: prev.categories.includes(category.name)
                          ? prev.categories.filter(c => c !== category.name)
                          : [...prev.categories, category.name]
                      }));
                    }}
                  >
                    <View style={styles.categoryFilterRow}>
                      <View style={[styles.categoryFilterIcon, { backgroundColor: category.color + '20' }]}>
                        <category.icon size={16} color={category.color} />
                      </View>
                      <Text style={[
                        styles.filterOptionText,
                        filterOptions.categories.includes(category.name) && styles.filterOptionTextSelected
                      ]}>
                        {category.name}
                      </Text>
                    </View>
                    {filterOptions.categories.includes(category.name) && (
                      <Check size={16} color="#14B8A6" />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Show Over Budget Only */}
            <View style={styles.filterSection}>
              <TouchableOpacity
                style={[
                  styles.filterOption,
                  filterOptions.showOverBudget && styles.filterOptionSelected
                ]}
                onPress={() => setFilterOptions(prev => ({ ...prev, showOverBudget: !prev.showOverBudget }))}
              >
                <Text style={[
                  styles.filterOptionText,
                  filterOptions.showOverBudget && styles.filterOptionTextSelected
                ]}>
                  Show Over Budget Only
                </Text>
                {filterOptions.showOverBudget && (
                  <Check size={16} color="#14B8A6" />
                )}
              </TouchableOpacity>
            </View>
          </ScrollView>

          <View style={styles.filterActions}>
            <TouchableOpacity 
              style={styles.resetButton}
              onPress={resetFilters}
            >
              <Text style={styles.resetButtonText}>Reset</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.applyButton}
              onPress={applyFilters}
            >
              <Text style={styles.applyButtonText}>Apply Filters</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Budget Overview</Text>
        <TouchableOpacity 
          style={styles.filterButton}
          onPress={handleFilterPress}
          activeOpacity={0.7}
        >
          <Filter size={20} color="#6B7280" />
        </TouchableOpacity>
      </View>

      <View style={styles.periodSelector}>
        {periods.map((period) => (
          <TouchableOpacity
            key={period}
            style={[
              styles.periodButton,
              selectedPeriod === period && styles.selectedPeriod
            ]}
            onPress={() => setSelectedPeriod(period)}
          >
            <Text style={[
              styles.periodText,
              selectedPeriod === period && styles.selectedPeriodText
            ]}>
              {period}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView 
        style={styles.scrollView} 
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={true}
        indicatorStyle="default"
        scrollIndicatorInsets={{ right: 1 }}
        bounces={true}
        alwaysBounceVertical={true}
      >
        {/* Daily Budget Card */}
        <DailyBudgetCard />

        <View style={styles.summaryCard}>
          <View style={styles.summaryHeader}>
            <Calendar size={24} color="#14B8A6" />
            <Text style={styles.summaryTitle}>This {selectedPeriod}</Text>
          </View>
          <View style={styles.summaryStats}>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Total Spent</Text>
              <Text style={styles.summaryAmount}>{formatCurrency(financialData.totalExpenses)}</Text>
            </View>
            <View style={styles.summaryDivider} />
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Total Budget</Text>
              <Text style={[styles.summaryAmount, { color: '#6B7280' }]}>
                {formatCurrency(categories.reduce((sum, cat) => sum + cat.budget, 0))}
              </Text>
            </View>
          </View>
          <View style={styles.overallProgress}>
            <View style={styles.overallProgressBar}>
              <View 
                style={[
                  styles.overallProgressFill, 
                  { width: `${(financialData.totalExpenses / categories.reduce((sum, cat) => sum + cat.budget, 0)) * 100}%` }
                ]} 
              />
            </View>
            <Text style={styles.overallProgressText}>
              {Math.round((financialData.totalExpenses / categories.reduce((sum, cat) => sum + cat.budget, 0)) * 100)}% of budget used
            </Text>
          </View>
        </View>

        <View style={styles.categoriesSection}>
          <View style={styles.categoriesHeader}>
            <Text style={styles.sectionTitle}>Categories</Text>
            <View style={styles.categoriesHeaderRight}>
              <Text style={styles.categoriesCount}>
                {filteredCategories.length} of {categories.length}
              </Text>
              <Text style={styles.editHint}>Tap ✏️ to edit budgets</Text>
            </View>
          </View>
          <View style={styles.categoriesList}>
            {filteredCategories.length > 0 ? (
              filteredCategories.map((category, index) => (
                <CategoryCard key={index} category={category} />
              ))
            ) : (
              <View style={styles.emptyState}>
                <Filter size={48} color="#9CA3AF" />
                <Text style={styles.emptyTitle}>No Categories Match</Text>
                <Text style={styles.emptyDescription}>
                  Try adjusting your filters to see more categories.
                </Text>
                <TouchableOpacity 
                  style={styles.resetFiltersButton}
                  onPress={resetFilters}
                >
                  <Text style={styles.resetFiltersButtonText}>Reset Filters</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>

        {/* Extra spacing at bottom for better scrolling */}
        <View style={styles.bottomSpacing} />
      </ScrollView>

      <FilterModal />
      <EditBudgetModal
        visible={showEditModal}
        category={editingCategory}
        onSave={handleSaveBudget}
        onCancel={() => {
          setShowEditModal(false);
          setEditingCategory(null);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingBottom: 8,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  filterButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  periodSelector: {
    flexDirection: 'row',
    backgroundColor: '#E5E7EB',
    borderRadius: 12,
    margin: 24,
    padding: 4,
  },
  periodButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  selectedPeriod: {
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  periodText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  selectedPeriodText: {
    color: '#14B8A6',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingBottom: 120,
  },
  // Daily Budget Card Styles
  dailyBudgetCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  dailyBudgetHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  dailyBudgetTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginLeft: 12,
    flex: 1,
  },
  dailyViewToggle: {
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  dailyViewToggleText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  dailyBudgetStats: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  dailyBudgetItem: {
    flex: 1,
    alignItems: 'center',
  },
  dailyBudgetDivider: {
    width: 1,
    backgroundColor: '#E5E7EB',
    marginHorizontal: 20,
  },
  dailyBudgetLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 4,
  },
  dailyBudgetAmount: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  dailyProgress: {
    alignItems: 'center',
    marginBottom: 16,
  },
  dailyProgressBar: {
    width: '100%',
    height: 8,
    backgroundColor: '#E5E7EB',
    borderRadius: 4,
    marginBottom: 8,
  },
  dailyProgressFill: {
    height: '100%',
    borderRadius: 4,
  },
  dailyProgressText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  dailyDetailsSection: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  dailyDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  dailyDetailLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    flex: 1,
  },
  dailyDetailValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  summaryCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  summaryTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginLeft: 12,
  },
  summaryStats: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  summaryItem: {
    flex: 1,
    alignItems: 'center',
  },
  summaryDivider: {
    width: 1,
    backgroundColor: '#E5E7EB',
    marginHorizontal: 20,
  },
  summaryLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 4,
  },
  summaryAmount: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  overallProgress: {
    alignItems: 'center',
  },
  overallProgressBar: {
    width: '100%',
    height: 8,
    backgroundColor: '#E5E7EB',
    borderRadius: 4,
    marginBottom: 8,
  },
  overallProgressFill: {
    height: '100%',
    backgroundColor: '#14B8A6',
    borderRadius: 4,
  },
  overallProgressText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  categoriesSection: {
    marginBottom: 24,
  },
  categoriesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginBottom: 16,
  },
  categoriesHeaderRight: {
    alignItems: 'flex-end',
  },
  categoriesCount: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  editHint: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    marginTop: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  categoriesList: {
    gap: 12,
  },
  categoryCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  categoryInfo: {
    flex: 1,
  },
  categoryName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  categoryAmount: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 2,
  },
  categoryDailyAmount: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    marginTop: 2,
  },
  categoryActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  percentageContainer: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  percentageText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  editButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressContainer: {
    marginBottom: 8,
  },
  progressLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#F3F4F6',
    borderRadius: 3,
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  warningContainer: {
    backgroundColor: '#FEF2F2',
    borderRadius: 8,
    padding: 8,
    marginTop: 8,
  },
  warningText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#DC2626',
    textAlign: 'center',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
    backgroundColor: 'white',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 24,
  },
  resetFiltersButton: {
    backgroundColor: '#14B8A6',
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  resetFiltersButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  bottomSpacing: {
    height: 40,
  },
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  filterModal: {
    backgroundColor: 'white',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '80%',
    paddingTop: 20,
  },
  filterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  filterTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  closeButton: {
    padding: 4,
  },
  filterContent: {
    flex: 1,
    paddingHorizontal: 24,
  },
  filterSection: {
    marginTop: 24,
  },
  filterSectionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 12,
  },
  filterOptions: {
    gap: 8,
  },
  filterOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    backgroundColor: 'white',
  },
  filterOptionSelected: {
    borderColor: '#14B8A6',
    backgroundColor: '#F0FDF4',
  },
  filterOptionText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  filterOptionTextSelected: {
    color: '#14B8A6',
  },
  categoryFilterRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryFilterIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  filterActions: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    paddingVertical: 20,
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  resetButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    alignItems: 'center',
  },
  resetButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  applyButton: {
    flex: 2,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#14B8A6',
    alignItems: 'center',
  },
  applyButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  // Edit Budget Modal Styles
  editModal: {
    backgroundColor: 'white',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '90%',
    paddingTop: 20,
  },
  editModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  editModalTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  editModalIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  editModalTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  editModalContent: {
    flex: 1,
    paddingHorizontal: 24,
    paddingVertical: 20,
  },
  currentBudgetInfo: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    alignItems: 'center',
  },
  currentBudgetLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 4,
  },
  currentBudgetAmount: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  currentSpentAmount: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  budgetInputSection: {
    marginBottom: 24,
  },
  inputLabel: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 12,
  },
  budgetInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    paddingHorizontal: 4,
  },
  adjustButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    margin: 4,
  },
  budgetInput: {
    flex: 1,
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    textAlign: 'center',
    paddingVertical: 12,
  },
  previewAmount: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#14B8A6',
    textAlign: 'center',
    marginTop: 8,
  },
  quickAmountSection: {
    marginBottom: 24,
  },
  quickAmountLabel: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 12,
  },
  quickAmountButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  quickAmountButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    backgroundColor: 'white',
  },
  quickAmountButtonSelected: {
    borderColor: '#14B8A6',
    backgroundColor: '#F0FDF4',
  },
  quickAmountButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  quickAmountButtonTextSelected: {
    color: '#14B8A6',
  },
  budgetTips: {
    backgroundColor: '#FEF3C7',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  budgetTipsTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#92400E',
    marginBottom: 8,
  },
  budgetTipsText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#92400E',
    lineHeight: 20,
  },
  editModalActions: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    paddingVertical: 20,
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  cancelButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  saveButton: {
    flex: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#14B8A6',
    gap: 8,
  },
  saveButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
});
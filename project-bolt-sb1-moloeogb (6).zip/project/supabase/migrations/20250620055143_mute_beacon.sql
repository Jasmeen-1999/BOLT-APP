/*
  # Create blockchain_rewards table

  1. New Tables
    - `blockchain_rewards`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users table)
      - `token_id` (text, unique token identifier)
      - `reward_type` (text, type of reward/badge)
      - `amount_saved` (numeric, amount saved to earn this reward)
      - `month` (text, month when reward was earned)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `blockchain_rewards` table
    - Add policy for authenticated users to read their own rewards
    - Add policy for authenticated users to insert their own rewards

  3. Indexes
    - Add index on user_id for faster queries
    - Add unique constraint on token_id
*/

-- Create blockchain_rewards table
CREATE TABLE IF NOT EXISTS blockchain_rewards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_id text UNIQUE NOT NULL,
  reward_type text NOT NULL,
  amount_saved numeric NOT NULL DEFAULT 0,
  month text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE blockchain_rewards ENABLE ROW LEVEL SECURITY;

-- Create policies for RLS
CREATE POLICY "Users can read own rewards"
  ON blockchain_rewards
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own rewards"
  ON blockchain_rewards
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS blockchain_rewards_user_id_idx ON blockchain_rewards(user_id);
CREATE INDEX IF NOT EXISTS blockchain_rewards_created_at_idx ON blockchain_rewards(created_at DESC);

-- Add unique constraint on user_id and month combination to prevent duplicate rewards for same month
CREATE UNIQUE INDEX IF NOT EXISTS blockchain_rewards_user_month_unique 
  ON blockchain_rewards(user_id, month);
import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  Bot,
  Send,
  Mic,
  MicOff,
  Video,
  Play,
  Pause,
  Volume2,
  VolumeX,
  MessageSquare,
  Sparkles
} from 'lucide-react-native';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  hasAudio?: boolean;
  hasVideo?: boolean;
}

export default function Coach() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm your personal finance coach. I'm here to help you make smarter financial decisions and reach your savings goals. How can I assist you today?",
      isUser: false,
      timestamp: new Date(),
      hasVideo: true,
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  const sendMessage = async (text: string, isVoice: boolean = false) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: text.trim(),
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    // Simulate API call to coach service
    setTimeout(() => {
      const coachResponse = generateCoachResponse(text);
      const coachMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: coachResponse.text,
        isUser: false,
        timestamp: new Date(),
        hasAudio: coachResponse.hasAudio,
        hasVideo: coachResponse.hasVideo,
      };

      setMessages(prev => [...prev, coachMessage]);
      setIsLoading(false);
    }, 1500);

    // Scroll to bottom
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const generateCoachResponse = (userText: string): { text: string; hasAudio: boolean; hasVideo: boolean } => {
    const lowerText = userText.toLowerCase();
    
    if (lowerText.includes('save') || lowerText.includes('saving')) {
      return {
        text: "Great question about saving! Based on your spending patterns, I recommend the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings. You're currently saving 18% - just 2% away from the goal! Would you like a personalized video explaining specific strategies for your situation?",
        hasAudio: true,
        hasVideo: true,
      };
    } else if (lowerText.includes('budget') || lowerText.includes('expense')) {
      return {
        text: "I've analyzed your recent expenses and noticed you're spending 15% more on dining out this month. Here's a tip: try meal prepping on Sundays - it can save you ₹3,000-4,000 monthly! I can create a personalized meal budget plan. Would you like me to show you in a video?",
        hasAudio: true,
        hasVideo: true,
      };
    } else if (lowerText.includes('goal') || lowerText.includes('target')) {
      return {
        text: "Setting financial goals is crucial! I see you're 60% towards your savings goal. To reach ₹2,000 by month-end, you need to save ₹400 more. I suggest cutting entertainment expenses by 20% and finding one subscription to pause. Let me explain this strategy in detail.",
        hasAudio: true,
        hasVideo: true,
      };
    } else {
      return {
        text: "I understand your concern. Let me analyze your financial data and provide personalized advice. Based on your spending patterns, I can help you optimize your budget and reach your financial goals faster. What specific area would you like to focus on?",
        hasAudio: true,
        hasVideo: false,
      };
    }
  };

  const startVoiceRecording = () => {
    if (Platform.OS === 'web') {
      Alert.alert('Voice Recording', 'Voice recording is not available on web. Please type your message.');
      return;
    }
    
    setIsRecording(true);
    // Implement voice recording logic here
    setTimeout(() => {
      setIsRecording(false);
      sendMessage("How can I save more money this month?", true);
    }, 3000);
  };

  const stopVoiceRecording = () => {
    setIsRecording(false);
  };

  const playVideo = (messageId: string) => {
    // Implement Tavus video playback
    setIsVideoPlaying(true);
    Alert.alert('Video Coach', 'Playing personalized video message from your finance coach!');
    setTimeout(() => {
      setIsVideoPlaying(false);
    }, 3000);
  };

  const toggleAudio = () => {
    setIsMuted(!isMuted);
  };

  const MessageBubble = ({ message }: { message: Message }) => (
    <View style={[
      styles.messageBubble,
      message.isUser ? styles.userMessage : styles.coachMessage
    ]}>
      {!message.isUser && (
        <View style={styles.coachAvatar}>
          <Bot size={16} color="white" />
        </View>
      )}
      
      <View style={[
        styles.messageContent,
        message.isUser ? styles.userContent : styles.coachContent
      ]}>
        <Text style={[
          styles.messageText,
          message.isUser ? styles.userText : styles.coachText
        ]}>
          {message.text}
        </Text>
        
        {message.hasVideo && (
          <TouchableOpacity 
            style={styles.videoButton}
            onPress={() => playVideo(message.id)}
          >
            <Video size={16} color="#14B8A6" />
            <Text style={styles.videoText}>Watch Video Response</Text>
          </TouchableOpacity>
        )}
        
        {message.hasAudio && (
          <TouchableOpacity style={styles.audioButton}>
            <Volume2 size={16} color="#6B7280" />
            <Text style={styles.audioText}>Play Audio</Text>
          </TouchableOpacity>
        )}
        
        <Text style={styles.timestamp}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient
        colors={['#14B8A6', '#3B82F6']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <View style={styles.coachInfo}>
            <View style={styles.coachIcon}>
              <Bot size={24} color="white" />
            </View>
            <View>
              <Text style={styles.coachName}>AI Finance Coach</Text>
              <Text style={styles.coachStatus}>Online • Ready to help</Text>
            </View>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.headerButton} onPress={toggleAudio}>
              {isMuted ? <VolumeX size={20} color="white" /> : <Volume2 size={20} color="white" />}
            </TouchableOpacity>
            <TouchableOpacity style={styles.headerButton}>
              <Sparkles size={20} color="white" />
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>

      <ScrollView
        ref={scrollViewRef}
        style={styles.chatContainer}
        contentContainerStyle={styles.chatContent}
        showsVerticalScrollIndicator={false}
      >
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
        
        {isLoading && (
          <View style={styles.loadingContainer}>
            <View style={styles.coachAvatar}>
              <Bot size={16} color="white" />
            </View>
            <View style={styles.loadingBubble}>
              <View style={styles.typingIndicator}>
                <View style={styles.dot} />
                <View style={styles.dot} />
                <View style={styles.dot} />
              </View>
            </View>
          </View>
        )}
      </ScrollView>

      <SafeAreaView edges={['bottom']}>
        <View style={styles.inputContainer}>
          <View style={styles.inputRow}>
            <TextInput
              style={styles.textInput}
              placeholder="Ask your finance coach anything..."
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
            />
            <TouchableOpacity
              style={styles.sendButton}
              onPress={() => sendMessage(inputText)}
              disabled={!inputText.trim() || isLoading}
            >
              <Send size={20} color={inputText.trim() ? "#14B8A6" : "#9CA3AF"} />
            </TouchableOpacity>
          </View>
          
          <View style={styles.quickActions}>
            <TouchableOpacity
              style={[styles.voiceButton, isRecording && styles.recording]}
              onPress={isRecording ? stopVoiceRecording : startVoiceRecording}
            >
              {isRecording ? <MicOff size={20} color="white" /> : <Mic size={20} color="#14B8A6" />}
              <Text style={[styles.actionText, isRecording && styles.recordingText]}>
                {isRecording ? 'Recording...' : 'Voice'}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={() => sendMessage("How can I save more money this month?")}
            >
              <MessageSquare size={16} color="#6B7280" />
              <Text style={styles.quickActionText}>Save Money</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={() => sendMessage("Analyze my spending patterns")}
            >
              <MessageSquare size={16} color="#6B7280" />
              <Text style={styles.quickActionText}>Spending Analysis</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingHorizontal: 24,
    paddingBottom: 16,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  coachInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  coachIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  coachName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  coachStatus: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255, 255, 255, 0.8)',
    marginTop: 2,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  headerButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  chatContainer: {
    flex: 1,
  },
  chatContent: {
    padding: 24,
    paddingBottom: 100,
  },
  messageBubble: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-end',
  },
  userMessage: {
    justifyContent: 'flex-end',
  },
  coachMessage: {
    justifyContent: 'flex-start',
  },
  coachAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#14B8A6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
    marginBottom: 4,
  },
  messageContent: {
    maxWidth: '75%',
    borderRadius: 16,
    padding: 12,
  },
  userContent: {
    backgroundColor: '#14B8A6',
    borderBottomRightRadius: 4,
  },
  coachContent: {
    backgroundColor: 'white',
    borderBottomLeftRadius: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  messageText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    lineHeight: 20,
  },
  userText: {
    color: 'white',
  },
  coachText: {
    color: '#1F2937',
  },
  videoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0FDF4',
    borderRadius: 8,
    padding: 8,
    marginTop: 8,
  },
  videoText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#14B8A6',
    marginLeft: 4,
  },
  audioButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  audioText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
  timestamp: {
    fontSize: 10,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    marginTop: 4,
    textAlign: 'right',
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 16,
  },
  loadingBubble: {
    backgroundColor: 'white',
    borderRadius: 16,
    borderBottomLeftRadius: 4,
    padding: 16,
    marginLeft: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  typingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#9CA3AF',
  },
  inputContainer: {
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 16,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: '#F9FAFB',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginBottom: 12,
  },
  textInput: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
    maxHeight: 100,
    paddingTop: 8,
    paddingBottom: 8,
  },
  sendButton: {
    padding: 8,
    marginLeft: 8,
  },
  quickActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  voiceButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0FDF4',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#14B8A6',
  },
  recording: {
    backgroundColor: '#EF4444',
    borderColor: '#EF4444',
  },
  actionText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#14B8A6',
    marginLeft: 4,
  },
  recordingText: {
    color: 'white',
  },
  quickActionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 16,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  quickActionText: {
    fontSize: 11,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
});
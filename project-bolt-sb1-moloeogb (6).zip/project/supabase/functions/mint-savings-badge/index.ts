/*
  # Mint Savings Badge Edge Function

  This function automatically mints a badge token when a user saves ₹1000 or more in a month.
  
  ## Features
  - Calculates monthly savings from income and expenses
  - Mints different badge types based on savings amount
  - Prevents duplicate badges for the same month
  - Generates unique Algorand token IDs
  - Updates user rewards in blockchain_rewards table
*/

import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface MintBadgeRequest {
  userId: string;
  month?: string; // Optional, defaults to current month
}

interface SavingsData {
  totalIncome: number;
  totalExpenses: number;
  savings: number;
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Parse request body
    const { userId, month }: MintBadgeRequest = await req.json();

    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'User ID is required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Calculate target month (current month if not specified)
    const targetDate = month ? new Date(month) : new Date();
    const year = targetDate.getFullYear();
    const monthNum = targetDate.getMonth();
    const monthName = targetDate.toLocaleString('default', { month: 'long', year: 'numeric' });
    
    // Calculate month boundaries
    const startOfMonth = new Date(year, monthNum, 1).toISOString();
    const endOfMonth = new Date(year, monthNum + 1, 0, 23, 59, 59).toISOString();

    // Check if badge already exists for this month
    const { data: existingBadge } = await supabase
      .from('blockchain_rewards')
      .select('id')
      .eq('user_id', userId)
      .eq('month', monthName)
      .single();

    if (existingBadge) {
      return new Response(
        JSON.stringify({ 
          message: 'Badge already exists for this month',
          month: monthName 
        }),
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Calculate monthly savings
    const savingsData = await calculateMonthlySavings(supabase, userId, startOfMonth, endOfMonth);

    // Check if user qualifies for a badge (saved at least ₹1000)
    if (savingsData.savings < 1000) {
      return new Response(
        JSON.stringify({ 
          message: 'User has not saved enough to qualify for a badge',
          savings: savingsData.savings,
          required: 1000,
          month: monthName
        }),
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Determine badge type based on savings amount
    const badgeInfo = determineBadgeType(savingsData.savings);

    // Generate unique token ID
    const tokenId = generateTokenId(userId, monthName);

    // Mint the badge token
    const { data: newBadge, error: mintError } = await supabase
      .from('blockchain_rewards')
      .insert({
        user_id: userId,
        token_id: tokenId,
        reward_type: badgeInfo.type,
        amount_saved: savingsData.savings,
        month: monthName,
      })
      .select()
      .single();

    if (mintError) {
      console.error('Error minting badge:', mintError);
      return new Response(
        JSON.stringify({ error: 'Failed to mint badge token' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Return success response
    return new Response(
      JSON.stringify({
        success: true,
        message: 'Badge token minted successfully!',
        badge: {
          tokenId: newBadge.token_id,
          type: newBadge.reward_type,
          amountSaved: newBadge.amount_saved,
          month: newBadge.month,
          rarity: badgeInfo.rarity,
        },
        savings: savingsData,
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in mint-savings-badge function:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

async function calculateMonthlySavings(
  supabase: any, 
  userId: string, 
  startOfMonth: string, 
  endOfMonth: string
): Promise<SavingsData> {
  // Get total income for the month
  const { data: incomeData } = await supabase
    .from('income')
    .select('amount')
    .eq('user_id', userId)
    .gte('date', startOfMonth)
    .lte('date', endOfMonth);

  // Get total expenses for the month
  const { data: expenseData } = await supabase
    .from('expenses')
    .select('amount')
    .eq('user_id', userId)
    .gte('date', startOfMonth)
    .lte('date', endOfMonth);

  const totalIncome = incomeData?.reduce((sum, record) => sum + record.amount, 0) || 0;
  const totalExpenses = expenseData?.reduce((sum, record) => sum + record.amount, 0) || 0;
  const savings = totalIncome - totalExpenses;

  return {
    totalIncome,
    totalExpenses,
    savings: Math.max(0, savings), // Ensure savings is not negative
  };
}

function determineBadgeType(savings: number): { type: string; rarity: string } {
  if (savings >= 10000) {
    return { type: 'Legendary Saver', rarity: 'Legendary' };
  } else if (savings >= 5000) {
    return { type: 'Epic Saver', rarity: 'Epic' };
  } else if (savings >= 2500) {
    return { type: 'Rare Saver', rarity: 'Rare' };
  } else {
    return { type: 'Saver Badge', rarity: 'Common' };
  }
}

function generateTokenId(userId: string, month: string): string {
  // Create a unique token ID using user ID, month, and timestamp
  const timestamp = Date.now();
  const hash = btoa(`${userId}-${month}-${timestamp}`).replace(/[^a-zA-Z0-9]/g, '').substring(0, 8);
  return `ALG${hash.toUpperCase()}`;
}
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Platform,
  TextInput,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '@/contexts/AuthContext';
import { router } from 'expo-router';
import { User, Settings as SettingsIcon, Bell, Shield, CreditCard, Crown, CircleHelp as HelpCircle, LogOut, ChevronRight, Mail, Smartphone, Globe, Star, Award, Calendar, CreditCard as Edit, Lock, Languages, ChartBar as BarChart3, Gift, Target, X, Save, Phone, MessageCircle, BookOpen } from 'lucide-react-native';

interface EditModalProps {
  visible: boolean;
  title: string;
  currentValue: string;
  placeholder: string;
  onSave: (value: string) => void;
  onCancel: () => void;
  keyboardType?: 'default' | 'email-address' | 'numeric' | 'phone-pad';
}

function EditModal({ visible, title, currentValue, placeholder, onSave, onCancel, keyboardType = 'default' }: EditModalProps) {
  const [value, setValue] = useState(currentValue);

  React.useEffect(() => {
    setValue(currentValue);
  }, [currentValue, visible]);

  const handleSave = () => {
    if (value.trim()) {
      onSave(value.trim());
    } else {
      Alert.alert('Error', 'Please enter a valid value');
    }
  };

  const handleCancel = () => {
    setValue(currentValue);
    onCancel();
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={handleCancel}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>{title}</Text>
            <TouchableOpacity onPress={handleCancel} style={styles.closeButton}>
              <X size={24} color="#6B7280" />
            </TouchableOpacity>
          </View>
          
          <TextInput
            style={styles.modalInput}
            placeholder={placeholder}
            value={value}
            onChangeText={setValue}
            keyboardType={keyboardType}
            autoFocus
            placeholderTextColor="#9CA3AF"
          />
          
          <View style={styles.modalButtons}>
            <TouchableOpacity style={styles.modalCancelButton} onPress={handleCancel}>
              <Text style={styles.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.modalSaveButton} onPress={handleSave}>
              <Save size={16} color="white" />
              <Text style={styles.modalSaveText}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

export default function Settings() {
  const { user, signOut } = useAuth();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [emailUpdates, setEmailUpdates] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editModalConfig, setEditModalConfig] = useState({
    title: '',
    currentValue: '',
    placeholder: '',
    onSave: (value: string) => {},
    keyboardType: 'default' as const,
  });

  const showEditModal = (title: string, currentValue: string, placeholder: string, onSave: (value: string) => void, keyboardType: 'default' | 'email-address' | 'numeric' | 'phone-pad' = 'default') => {
    console.log('Opening edit modal:', title);
    setEditModalConfig({ title, currentValue, placeholder, onSave, keyboardType });
    setEditModalVisible(true);
  };

  const handleSignOut = async () => {
    console.log('Sign out button pressed');
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Sign Out', 
          style: 'destructive', 
          onPress: async () => {
            try {
              await signOut();
              router.replace('/(auth)/sign-in');
            } catch (error) {
              Alert.alert('Error', 'Failed to sign out. Please try again.');
            }
          }
        },
      ]
    );
  };

  const upgradeToPremium = () => {
    console.log('Upgrade to Premium button pressed');
    Alert.alert(
      'Upgrade to Premium 👑',
      'Unlock exclusive features:\n\n• Advanced Analytics & Reports\n• Unlimited AI Coaching Sessions\n• Exclusive Blockchain Rewards\n• Priority Customer Support\n• Custom Financial Goals\n• Export Data Features\n\n💰 Special Launch Price: ₹299/month\n(Regular price: ₹499/month)',
      [
        { text: 'Maybe Later', style: 'cancel' },
        { 
          text: 'Upgrade Now', 
          onPress: () => {
            Alert.alert(
              'Coming Soon! 🚀', 
              'Premium subscription will be available soon! We\'re working hard to bring you the best financial coaching experience.\n\n📧 Want early access? We\'ll notify you when it\'s ready!\n\nStay tuned for updates!'
            );
          }
        },
      ]
    );
  };

  const handlePersonalInfo = () => {
    console.log('Personal Information button pressed');
    Alert.alert(
      'Edit Personal Information ✏️',
      'What would you like to update?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Change Name', 
          onPress: () => {
            showEditModal(
              'Update Full Name',
              user?.full_name || '',
              'Enter your full name',
              (newName) => {
                setEditModalVisible(false);
                Alert.alert('Success! ✅', `Your name has been updated to "${newName}"\n\nNote: This is a demo - in the full app, this would sync with your account.`);
              }
            );
          }
        },
        { 
          text: 'Change Email', 
          onPress: () => {
            showEditModal(
              'Update Email Address',
              user?.email || '',
              'Enter your email address',
              (newEmail) => {
                setEditModalVisible(false);
                Alert.alert('Success! ✅', `Your email has been updated to "${newEmail}"\n\nNote: This is a demo - in the full app, you would receive a verification email.`);
              },
              'email-address'
            );
          }
        },
        { 
          text: 'Upload Photo', 
          onPress: () => {
            Alert.alert(
              'Profile Photo 📸',
              'Choose how to update your profile picture:',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Take Photo', onPress: () => Alert.alert('Camera', 'Camera feature coming soon!') },
                { text: 'Choose from Gallery', onPress: () => Alert.alert('Gallery', 'Gallery feature coming soon!') },
              ]
            );
          }
        }
      ]
    );
  };

  const handlePaymentMethods = () => {
    console.log('Payment Methods button pressed');
    Alert.alert(
      'Payment Methods 💳',
      'Manage your payment options:',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Add Card', 
          onPress: () => {
            Alert.alert(
              'Add Payment Method',
              'Choose payment method type:',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Credit Card', onPress: () => Alert.alert('Credit Card', 'Secure card integration coming soon!') },
                { text: 'Debit Card', onPress: () => Alert.alert('Debit Card', 'Debit card support coming soon!') },
                { text: 'UPI', onPress: () => Alert.alert('UPI', 'UPI integration coming soon!') },
                { text: 'Net Banking', onPress: () => Alert.alert('Net Banking', 'Net banking support coming soon!') },
              ]
            );
          }
        },
        { 
          text: 'View Saved Cards', 
          onPress: () => {
            Alert.alert('Saved Cards', 'No saved payment methods found.\n\nAdd a payment method to get started with premium features!');
          }
        },
        { 
          text: 'Security Info', 
          onPress: () => {
            Alert.alert(
              'Payment Security 🔒',
              'Your payment information is protected with:\n\n• Bank-level encryption\n• PCI DSS compliance\n• Secure tokenization\n• No card details stored locally\n• 24/7 fraud monitoring\n\nWe never store your payment details on our servers!'
            );
          }
        }
      ]
    );
  };

  const handlePrivacySecurity = () => {
    console.log('Privacy & Security button pressed');
    Alert.alert(
      'Privacy & Security 🔒',
      'Protect your account:',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Change Password', 
          onPress: () => {
            Alert.alert(
              'Change Password',
              'For security, you\'ll be redirected to a secure page to update your password.',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Continue', onPress: () => Alert.alert('Redirect', 'Password change feature coming soon!') }
              ]
            );
          }
        },
        { 
          text: 'Two-Factor Auth', 
          onPress: () => {
            Alert.alert(
              'Two-Factor Authentication 🔐',
              'Add an extra layer of security to your account:',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'SMS Verification', onPress: () => Alert.alert('SMS 2FA', 'SMS two-factor authentication coming soon!') },
                { text: 'Authenticator App', onPress: () => Alert.alert('App 2FA', 'Authenticator app support coming soon!') },
              ]
            );
          }
        },
        { 
          text: 'Login Activity', 
          onPress: () => {
            Alert.alert(
              'Recent Login Activity 📱',
              'Your recent login sessions:\n\n• Web Browser - Today, 2:30 PM\n• Mobile App - Yesterday, 8:45 AM\n• Web Browser - 2 days ago, 6:15 PM\n\nAll sessions appear normal. If you notice any suspicious activity, please contact support immediately.'
            );
          }
        },
        { 
          text: 'Download Data', 
          onPress: () => {
            Alert.alert(
              'Download Your Data 📥',
              'Export all your personal data including:\n\n• Account information\n• Transaction history\n• Budget data\n• Rewards earned\n• App preferences\n\nThis may take a few minutes to prepare.',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Request Export', onPress: () => Alert.alert('Export Requested', 'Your data export has been requested. You\'ll receive an email when it\'s ready for download.') }
              ]
            );
          }
        }
      ]
    );
  };

  const handleLanguageRegion = () => {
    console.log('Language & Region button pressed');
    Alert.alert(
      'Language & Region 🌍',
      'Current Settings:\n• Language: English (India)\n• Currency: Indian Rupee (₹)\n• Date format: DD/MM/YYYY\n• Number format: Indian\n\nWhat would you like to change?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Change Language', 
          onPress: () => {
            Alert.alert(
              'Select Language',
              'Choose your preferred language:',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'English (India)', onPress: () => Alert.alert('Language', 'English (India) is already selected!') },
                { text: 'हिंदी (Hindi)', onPress: () => Alert.alert('Coming Soon', 'Hindi language support coming soon!') },
                { text: 'বাংলা (Bengali)', onPress: () => Alert.alert('Coming Soon', 'Bengali language support coming soon!') },
                { text: 'தமிழ் (Tamil)', onPress: () => Alert.alert('Coming Soon', 'Tamil language support coming soon!') },
              ]
            );
          }
        },
        { 
          text: 'Change Currency', 
          onPress: () => {
            Alert.alert(
              'Select Currency',
              'Choose your preferred currency:',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: '₹ Indian Rupee', onPress: () => Alert.alert('Currency', 'Indian Rupee is already selected!') },
                { text: '$ US Dollar', onPress: () => Alert.alert('Coming Soon', 'USD support coming soon!') },
                { text: '€ Euro', onPress: () => Alert.alert('Coming Soon', 'Euro support coming soon!') },
              ]
            );
          }
        },
        { 
          text: 'Date Format', 
          onPress: () => {
            Alert.alert(
              'Date Format',
              'Choose your preferred date format:',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'DD/MM/YYYY', onPress: () => Alert.alert('Date Format', 'DD/MM/YYYY is already selected!') },
                { text: 'MM/DD/YYYY', onPress: () => Alert.alert('Updated', 'Date format changed to MM/DD/YYYY') },
                { text: 'YYYY-MM-DD', onPress: () => Alert.alert('Updated', 'Date format changed to YYYY-MM-DD') },
              ]
            );
          }
        }
      ]
    );
  };

  const handleAdvancedAnalytics = () => {
    console.log('Advanced Analytics button pressed');
    if (user?.is_premium) {
      Alert.alert(
        'Advanced Analytics 📊',
        'Premium analytics features:\n\n• Detailed spending reports\n• Investment tracking\n• Cash flow analysis\n• Budget vs actual comparisons\n• Predictive insights\n• Export capabilities\n\nFull analytics dashboard coming soon!',
        [
          { text: 'Preview Features', onPress: () => Alert.alert('Preview', 'Analytics preview coming soon!') },
          { text: 'OK' }
        ]
      );
    } else {
      Alert.alert(
        'Advanced Analytics 📊',
        'Unlock powerful insights with Premium:\n\n• Detailed spending patterns\n• Investment performance tracking\n• Cash flow predictions\n• Custom report generation\n• Export capabilities\n• AI-powered recommendations\n\nUpgrade to Premium to access these features!',
        [
          { text: 'Maybe Later', style: 'cancel' },
          { text: 'Upgrade Now', onPress: upgradeToPremium }
        ]
      );
    }
  };

  const handleExclusiveRewards = () => {
    console.log('Exclusive Rewards button pressed');
    if (user?.is_premium) {
      Alert.alert(
        'Premium Rewards 🎁',
        'You have access to exclusive premium rewards!\n\n• Rare blockchain badges\n• Higher reward multipliers\n• Special achievement unlocks\n• Priority reward processing\n• Exclusive NFT rewards\n\nCheck your rewards tab to see your premium benefits!',
        [
          { text: 'View Rewards', onPress: () => router.push('/(tabs)/rewards') },
          { text: 'OK' }
        ]
      );
    } else {
      Alert.alert(
        'Exclusive Rewards 🎁',
        'Premium members get access to:\n\n• Rare blockchain badges\n• Higher reward multipliers (2x-5x)\n• Special achievement unlocks\n• Priority reward processing\n• Exclusive NFT rewards\n• Early access to new features\n\nUpgrade to Premium to unlock exclusive rewards!',
        [
          { text: 'View Current Rewards', onPress: () => router.push('/(tabs)/rewards') },
          { text: 'Upgrade Now', onPress: upgradeToPremium }
        ]
      );
    }
  };

  const handleCustomGoals = () => {
    console.log('Custom Goals button pressed');
    if (user?.is_premium) {
      Alert.alert(
        'Custom Goals 🎯',
        'Premium goal features:\n\n• Set unlimited financial goals\n• Create custom categories\n• Advanced progress tracking\n• Goal sharing with family\n• Automated goal suggestions\n• Smart milestone alerts\n\nAdvanced goal management coming soon!',
        [
          { text: 'Create Goal', onPress: () => Alert.alert('Goal Creator', 'Custom goal creator coming soon!') },
          { text: 'OK' }
        ]
      );
    } else {
      Alert.alert(
        'Custom Goals 🎯',
        'Premium goal features:\n\n• Unlimited financial goals\n• Custom goal categories\n• Advanced milestone tracking\n• Family goal sharing\n• AI-powered recommendations\n• Smart notifications\n\nUpgrade to Premium to unlock unlimited goals!',
        [
          { text: 'Maybe Later', style: 'cancel' },
          { text: 'Upgrade Now', onPress: upgradeToPremium }
        ]
      );
    }
  };

  const handleHelpSupport = () => {
    console.log('Help & Support button pressed');
    Alert.alert(
      'Help & Support 🤝',
      'We\'re here to help you succeed!\n\n📧 Email: support@financecoach.app\n📱 Phone: +91 98765 43210\n💬 Live Chat: Available 9 AM - 6 PM IST\n📚 Help Center: financecoach.app/help\n\nHow would you like to get help?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Email Support', 
          onPress: () => {
            Alert.alert(
              'Email Support 📧',
              'Send your questions to:\nsupport@financecoach.app\n\n• Response time: Within 24 hours\n• Include your user ID for faster support\n• Attach screenshots if needed\n\nWe typically respond within 24 hours!',
              [
                { text: 'Copy Email', onPress: () => Alert.alert('Copied!', 'Email address copied to clipboard') },
                { text: 'OK' }
              ]
            );
          }
        },
        { 
          text: 'Call Support', 
          onPress: () => {
            Alert.alert(
              'Phone Support 📞',
              'Call us at: +91 98765 43210\n\n• Support hours: 9 AM - 6 PM IST\n• Monday to Friday\n• Hindi and English support\n• Average wait time: 2-3 minutes',
              [
                { text: 'Call Now', onPress: () => Alert.alert('Calling...', 'Opening phone app to call support') },
                { text: 'OK' }
              ]
            );
          }
        },
        { 
          text: 'Live Chat', 
          onPress: () => {
            Alert.alert(
              'Live Chat 💬',
              'Chat with our support team:\n\n• Available: 9 AM - 6 PM IST\n• Average response: 30 seconds\n• Screen sharing available\n• File sharing supported\n\nLive chat feature coming soon!',
              [
                { text: 'Start Chat', onPress: () => Alert.alert('Coming Soon', 'Live chat feature will be available in the next update!') },
                { text: 'OK' }
              ]
            );
          }
        },
        { 
          text: 'FAQ', 
          onPress: () => {
            Alert.alert(
              'Frequently Asked Questions',
              'Common questions and answers:\n\n• How do I add transactions?\n• How are rewards calculated?\n• Is my data secure?\n• How do I upgrade to Premium?\n• How do I export my data?\n• How do I change my password?\n• How do I contact support?\n\nFor detailed answers, visit our help center!',
              [
                { text: 'Visit Help Center', onPress: () => Alert.alert('Help Center', 'Opening help center in browser...') },
                { text: 'OK' }
              ]
            );
          }
        }
      ]
    );
  };

  const handleNotificationToggle = (value: boolean) => {
    console.log('Notification toggle changed to:', value);
    setNotificationsEnabled(value);
    if (value) {
      Alert.alert(
        'Notifications Enabled ✅',
        'You\'ll receive important updates about:\n\n• Financial goals progress\n• New achievements earned\n• Budget alerts\n• Weekly summaries\n• Security notifications\n\nYou can customize notification types in the full app!'
      );
    } else {
      Alert.alert(
        'Notifications Disabled ❌',
        'You won\'t receive push notifications, but you can:\n\n• Still check updates in the app\n• Re-enable anytime in settings\n• Receive critical security alerts\n\nYou can re-enable notifications anytime.'
      );
    }
  };

  const handleEmailToggle = (value: boolean) => {
    console.log('Email updates toggle changed to:', value);
    setEmailUpdates(value);
    if (value) {
      Alert.alert(
        'Email Updates Enabled ✅',
        'You\'ll receive weekly emails with:\n\n• Financial summaries\n• Helpful money-saving tips\n• New feature announcements\n• Exclusive offers\n• Educational content\n\nEmails are sent every Sunday at 9 AM!'
      );
    } else {
      Alert.alert(
        'Email Updates Disabled ❌',
        'You won\'t receive weekly emails, but you\'ll still get:\n\n• Critical account notifications\n• Security alerts\n• Password reset emails\n\nYou can re-enable email updates anytime.'
      );
    }
  };

  const handleAppVersion = () => {
    console.log('App Version button pressed');
    Alert.alert(
      'App Information ℹ️',
      'Personal Finance Coach\nVersion: 1.0.0\nBuild: 2024.01.15\nPlatform: ' + Platform.OS + '\n\n🚀 What\'s New in v1.0.0:\n• Blockchain rewards system\n• AI-powered coaching\n• Advanced budget tracking\n• Beautiful new design\n• Enhanced security\n\n💝 Made with love for better financial health',
      [
        { text: 'OK', style: 'default' },
        { 
          text: 'Check for Updates', 
          onPress: () => {
            Alert.alert(
              'Check for Updates 🔄',
              'Checking for app updates...\n\nYou\'re running the latest version!\n\nNew features and improvements are added regularly. Enable auto-updates to get them automatically.',
              [
                { text: 'Enable Auto-Updates', onPress: () => Alert.alert('Auto-Updates', 'Auto-updates enabled! You\'ll get new features automatically.') },
                { text: 'OK' }
              ]
            );
          }
        },
        { 
          text: 'Rate App', 
          onPress: () => {
            Alert.alert(
              'Rate Our App ⭐',
              'Love using Personal Finance Coach?\n\nYour feedback helps us improve and reach more people who need better financial tools.\n\nApp store rating coming soon!',
              [
                { text: 'Maybe Later', style: 'cancel' },
                { text: 'Rate 5 Stars', onPress: () => Alert.alert('Thank You! ⭐⭐⭐⭐⭐', 'Thanks for your support! Your rating helps us grow.') }
              ]
            );
          }
        }
      ]
    );
  };

  const ProfileSection = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.sectionContent}>
        {children}
      </View>
    </View>
  );

  const ProfileRow = ({ 
    icon: Icon, 
    title, 
    subtitle, 
    onPress, 
    showChevron = true,
    rightElement,
    disabled = false
  }: {
    icon: any;
    title: string;
    subtitle?: string;
    onPress?: () => void;
    showChevron?: boolean;
    rightElement?: React.ReactNode;
    disabled?: boolean;
  }) => (
    <TouchableOpacity 
      style={[
        styles.profileRow, 
        disabled && styles.profileRowDisabled
      ]} 
      onPress={disabled ? undefined : onPress}
      activeOpacity={0.7}
    >
      <View style={styles.rowLeft}>
        <View style={[styles.rowIcon, disabled && styles.rowIconDisabled]}>
          <Icon size={20} color={disabled ? "#9CA3AF" : "#6B7280"} />
        </View>
        <View style={styles.rowContent}>
          <Text style={[styles.rowTitle, disabled && styles.rowTitleDisabled]}>{title}</Text>
          {subtitle && <Text style={[styles.rowSubtitle, disabled && styles.rowSubtitleDisabled]}>{subtitle}</Text>}
        </View>
      </View>
      <View style={styles.rowRight}>
        {rightElement}
        {showChevron && onPress && !disabled && <ChevronRight size={16} color="#9CA3AF" />}
      </View>
    </TouchableOpacity>
  );

  if (!user) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Please sign in to access settings</Text>
          <TouchableOpacity 
            style={styles.signInButton}
            onPress={() => router.replace('/(auth)/sign-in')}
            activeOpacity={0.8}
          >
            <Text style={styles.signInButtonText}>Go to Sign In</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {(user.full_name || user.email)?.[0]?.toUpperCase()}
            </Text>
          </View>
          {user.is_premium && (
            <View style={styles.premiumBadge}>
              <Crown size={12} color="#F59E0B" />
            </View>
          )}
        </View>
        <Text style={styles.userName}>{user.full_name || 'User'}</Text>
        <Text style={styles.userEmail}>{user.email}</Text>
        
        {!user.is_premium && (
          <TouchableOpacity 
            style={styles.upgradeButton} 
            onPress={upgradeToPremium}
            activeOpacity={0.8}
          >
            <Crown size={16} color="white" />
            <Text style={styles.upgradeText}>Upgrade to Premium</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView 
        style={styles.scrollView} 
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={true}
        indicatorStyle="default"
        scrollIndicatorInsets={{ right: 1 }}
        bounces={true}
        alwaysBounceVertical={true}
      >
        <ProfileSection title="Account">
          <ProfileRow
            icon={Edit}
            title="Personal Information"
            subtitle="Name, email, and profile settings"
            onPress={handlePersonalInfo}
          />
          <ProfileRow
            icon={CreditCard}
            title="Payment Methods"
            subtitle="Manage your payment options"
            onPress={handlePaymentMethods}
          />
          <ProfileRow
            icon={Lock}
            title="Privacy & Security"
            subtitle="Password, two-factor authentication"
            onPress={handlePrivacySecurity}
          />
        </ProfileSection>

        <ProfileSection title="Preferences">
          <ProfileRow
            icon={Bell}
            title="Push Notifications"
            subtitle="Get notified about your financial goals"
            showChevron={false}
            rightElement={
              <Switch
                value={notificationsEnabled}
                onValueChange={handleNotificationToggle}
                trackColor={{ false: '#E5E7EB', true: '#14B8A6' }}
                thumbColor={notificationsEnabled ? '#ffffff' : '#ffffff'}
                ios_backgroundColor="#E5E7EB"
              />
            }
          />
          <ProfileRow
            icon={Mail}
            title="Email Updates"
            subtitle="Weekly financial summaries and tips"
            showChevron={false}
            rightElement={
              <Switch
                value={emailUpdates}
                onValueChange={handleEmailToggle}
                trackColor={{ false: '#E5E7EB', true: '#14B8A6' }}
                thumbColor={emailUpdates ? '#ffffff' : '#ffffff'}
                ios_backgroundColor="#E5E7EB"
              />
            }
          />
          <ProfileRow
            icon={Languages}
            title="Language & Region"
            subtitle="English (India)"
            onPress={handleLanguageRegion}
          />
        </ProfileSection>

        <ProfileSection title="Premium Features">
          <ProfileRow
            icon={BarChart3}
            title="Advanced Analytics"
            subtitle={user.is_premium ? "View detailed reports" : "Unlock with Premium"}
            onPress={handleAdvancedAnalytics}
          />
          <ProfileRow
            icon={Gift}
            title="Exclusive Rewards"
            subtitle={user.is_premium ? "Access premium blockchain rewards" : "Upgrade to unlock"}
            onPress={handleExclusiveRewards}
          />
          <ProfileRow
            icon={Target}
            title="Custom Goals"
            subtitle={user.is_premium ? "Set unlimited financial goals" : "Premium feature"}
            onPress={handleCustomGoals}
          />
        </ProfileSection>

        <ProfileSection title="Support">
          <ProfileRow
            icon={HelpCircle}
            title="Help & Support"
            subtitle="Get help with your account"
            onPress={handleHelpSupport}
          />
          <ProfileRow
            icon={Smartphone}
            title="App Version"
            subtitle="Version 1.0.0"
            onPress={handleAppVersion}
            showChevron={true}
          />
        </ProfileSection>

        <View style={styles.dangerSection}>
          <TouchableOpacity 
            style={styles.signOutButton} 
            onPress={handleSignOut}
            activeOpacity={0.8}
          >
            <LogOut size={20} color="#EF4444" />
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Made with ❤️ for better financial health
          </Text>
          <Text style={styles.footerVersion}>
            Personal Finance Coach v1.0.0
          </Text>
        </View>

        {/* Extra spacing at bottom for better scrolling */}
        <View style={styles.bottomSpacing} />
      </ScrollView>

      <EditModal
        visible={editModalVisible}
        title={editModalConfig.title}
        currentValue={editModalConfig.currentValue}
        placeholder={editModalConfig.placeholder}
        onSave={editModalConfig.onSave}
        onCancel={() => setEditModalVisible(false)}
        keyboardType={editModalConfig.keyboardType}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  errorText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#EF4444',
    textAlign: 'center',
    marginBottom: 24,
  },
  signInButton: {
    backgroundColor: '#14B8A6',
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  signInButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 120,
  },
  header: {
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 32,
    paddingBottom: 32,
    backgroundColor: 'white',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#14B8A6',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  avatarText: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: 'white',
  },
  premiumBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FEF3C7',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'white',
  },
  userName: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 16,
  },
  upgradeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F59E0B',
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 10,
    shadowColor: '#F59E0B',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  upgradeText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
    marginLeft: 8,
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  sectionContent: {
    backgroundColor: 'white',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    overflow: 'hidden',
  },
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
    minHeight: 72,
  },
  profileRowDisabled: {
    opacity: 0.5,
  },
  rowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  rowIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  rowIconDisabled: {
    backgroundColor: '#F9FAFB',
  },
  rowContent: {
    flex: 1,
  },
  rowTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
  },
  rowTitleDisabled: {
    color: '#9CA3AF',
  },
  rowSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 2,
  },
  rowSubtitleDisabled: {
    color: '#D1D5DB',
  },
  rowRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  dangerSection: {
    paddingHorizontal: 24,
    marginTop: 24,
  },
  signOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    borderRadius: 16,
    paddingVertical: 16,
    borderWidth: 1,
    borderColor: '#FEE2E2',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  signOutText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#EF4444',
    marginLeft: 8,
  },
  footer: {
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 32,
    paddingBottom: 24,
  },
  footerText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 8,
  },
  footerVersion: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
  },
  bottomSpacing: {
    height: 40,
  },
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContainer: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 10,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  closeButton: {
    padding: 4,
  },
  modalInput: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
    marginBottom: 24,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalCancelButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  modalSaveButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#14B8A6',
    gap: 8,
  },
  modalSaveText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
});
import { supabase } from './supabase';

export interface BadgeReward {
  id: string;
  tokenId: string;
  rewardType: string;
  amountSaved: number;
  month: string;
  rarity: string;
  createdAt: string;
}

export const rewardsService = {
  /**
   * Check if user qualifies for a monthly savings badge and mint one if they do
   */
  async checkAndMintSavingsBadge(userId: string, month?: string): Promise<{ success: boolean; badge?: BadgeReward; message: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('mint-savings-badge', {
        body: { userId, month },
      });

      if (error) {
        console.error('Error calling mint-savings-badge function:', error);
        return { success: false, message: 'Failed to check savings badge eligibility' };
      }

      return {
        success: data.success || false,
        badge: data.badge,
        message: data.message || 'Badge check completed',
      };
    } catch (error) {
      console.error('Error in checkAndMintSavingsBadge:', error);
      return { success: false, message: 'An error occurred while checking badge eligibility' };
    }
  },

  /**
   * Get all rewards for a user
   */
  async getUserRewards(userId: string): Promise<BadgeReward[]> {
    try {
      const { data, error } = await supabase
        .from('blockchain_rewards')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching user rewards:', error);
        return [];
      }

      return data.map(reward => ({
        id: reward.id,
        tokenId: reward.token_id,
        rewardType: reward.reward_type,
        amountSaved: reward.amount_saved,
        month: reward.month,
        rarity: this.getRarityFromSavings(reward.amount_saved),
        createdAt: reward.created_at,
      }));
    } catch (error) {
      console.error('Error in getUserRewards:', error);
      return [];
    }
  },

  /**
   * Manually trigger badge check for current month
   */
  async triggerMonthlySavingsCheck(userId: string): Promise<{ success: boolean; message: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('check-monthly-savings', {
        body: { userId },
      });

      if (error) {
        console.error('Error calling check-monthly-savings function:', error);
        return { success: false, message: 'Failed to trigger savings check' };
      }

      return {
        success: data.success || false,
        message: data.message || 'Savings check completed',
      };
    } catch (error) {
      console.error('Error in triggerMonthlySavingsCheck:', error);
      return { success: false, message: 'An error occurred during savings check' };
    }
  },

  /**
   * Get rarity based on savings amount
   */
  getRarityFromSavings(savings: number): string {
    if (savings >= 10000) return 'Legendary';
    if (savings >= 5000) return 'Epic';
    if (savings >= 2500) return 'Rare';
    return 'Common';
  },

  /**
   * Get badge color based on rarity
   */
  getBadgeColor(rarity: string): string {
    switch (rarity) {
      case 'Legendary': return '#F59E0B';
      case 'Epic': return '#8B5CF6';
      case 'Rare': return '#3B82F6';
      case 'Common': return '#10B981';
      default: return '#6B7280';
    }
  },
};
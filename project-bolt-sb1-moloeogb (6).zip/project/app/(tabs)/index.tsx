import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Alert,
  TextInput,
  Modal,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '@/contexts/AuthContext';
import { useFinance } from '@/contexts/FinanceContext';
import { router } from 'expo-router';
import { TrendingUp, TrendingDown, DollarSign, Target, Calendar, Plus, Eye, CreditCard, ChartPie as PieChart, X } from 'lucide-react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

interface InputModalProps {
  visible: boolean;
  title: string;
  placeholder: string;
  onSubmit: (value: string) => void;
  onCancel: () => void;
}

function InputModal({ visible, title, placeholder, onSubmit, onCancel }: InputModalProps) {
  const [value, setValue] = useState('');

  const handleSubmit = () => {
    if (value.trim()) {
      onSubmit(value.trim());
      setValue('');
    }
  };

  const handleCancel = () => {
    setValue('');
    onCancel();
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={handleCancel}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>{title}</Text>
            <TouchableOpacity onPress={handleCancel} style={styles.closeButton}>
              <X size={24} color="#6B7280" />
            </TouchableOpacity>
          </View>
          
          <TextInput
            style={styles.modalInput}
            placeholder={placeholder}
            value={value}
            onChangeText={setValue}
            keyboardType="numeric"
            autoFocus
            placeholderTextColor="#9CA3AF"
          />
          
          <View style={styles.modalButtons}>
            <TouchableOpacity style={styles.modalCancelButton} onPress={handleCancel}>
              <Text style={styles.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.modalSubmitButton} onPress={handleSubmit}>
              <Text style={styles.modalSubmitText}>Add</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

export default function Dashboard() {
  const { user, loading } = useAuth();
  const { financialData, addIncome, addExpense, setSavingsGoal } = useFinance();
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalConfig, setModalConfig] = useState({
    title: '',
    placeholder: '',
    onSubmit: (value: string) => {},
  });

  useEffect(() => {
    if (!loading && !user) {
      router.replace('/(auth)/sign-in');
    }
  }, [user, loading]);

  const onRefresh = async () => {
    setRefreshing(true);
    // Simulate API call
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  const showInputModal = (title: string, placeholder: string, onSubmit: (value: string) => void) => {
    setModalConfig({ title, placeholder, onSubmit });
    setModalVisible(true);
  };

  const handleAddIncome = () => {
    if (Platform.OS === 'web') {
      showInputModal(
        'Add Income',
        'Enter income amount (₹)',
        (amount) => {
          const numAmount = parseFloat(amount);
          if (numAmount > 0) {
            addIncome(numAmount);
            Alert.alert('Success', `₹${numAmount.toLocaleString()} income added successfully!`);
          }
          setModalVisible(false);
        }
      );
    } else {
      Alert.alert(
        'Add Income',
        'Choose how to add income to your account',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Quick Add ₹5000', 
            onPress: () => {
              addIncome(5000);
              Alert.alert('Success', '₹5000 income added successfully!');
            }
          },
          { 
            text: 'Custom Amount', 
            onPress: () => {
              Alert.prompt(
                'Add Income',
                'Enter income amount:',
                (amount) => {
                  const numAmount = parseFloat(amount || '0');
                  if (numAmount > 0) {
                    addIncome(numAmount);
                    Alert.alert('Success', `₹${numAmount.toLocaleString()} income added successfully!`);
                  }
                },
                'plain-text',
                '',
                'numeric'
              );
            }
          },
        ]
      );
    }
  };

  const handleAddExpense = () => {
    if (Platform.OS === 'web') {
      showInputModal(
        'Add Expense',
        'Enter expense amount (₹)',
        (amount) => {
          const numAmount = parseFloat(amount);
          if (numAmount > 0) {
            addExpense(numAmount);
            Alert.alert('Success', `₹${numAmount.toLocaleString()} expense added successfully!`);
          }
          setModalVisible(false);
        }
      );
    } else {
      Alert.alert(
        'Add Expense',
        'Choose how to add an expense',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Quick Add ₹500', 
            onPress: () => {
              addExpense(500);
              Alert.alert('Success', '₹500 expense added successfully!');
            }
          },
          { 
            text: 'Custom Amount', 
            onPress: () => {
              Alert.prompt(
                'Add Expense',
                'Enter expense amount:',
                (amount) => {
                  const numAmount = parseFloat(amount || '0');
                  if (numAmount > 0) {
                    addExpense(numAmount);
                    Alert.alert('Success', `₹${numAmount.toLocaleString()} expense added successfully!`);
                  }
                },
                'plain-text',
                '',
                'numeric'
              );
            }
          },
        ]
      );
    }
  };

  const handleSetGoal = () => {
    if (Platform.OS === 'web') {
      showInputModal(
        'Set Savings Goal',
        'Enter savings goal amount (₹)',
        (amount) => {
          const numAmount = parseFloat(amount);
          if (numAmount > 0) {
            setSavingsGoal(numAmount);
            Alert.alert('Success', `Savings goal set to ₹${numAmount.toLocaleString()}!`);
          }
          setModalVisible(false);
        }
      );
    } else {
      Alert.alert(
        'Set Savings Goal',
        'Choose a savings goal option',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Set ₹5000 Goal', 
            onPress: () => {
              setSavingsGoal(5000);
              Alert.alert('Success', 'Savings goal set to ₹5000!');
            }
          },
          { 
            text: 'Set ₹10000 Goal', 
            onPress: () => {
              setSavingsGoal(10000);
              Alert.alert('Success', 'Savings goal set to ₹10000!');
            }
          },
          { 
            text: 'Custom Goal', 
            onPress: () => {
              Alert.prompt(
                'Set Savings Goal',
                'Enter your savings goal amount:',
                (amount) => {
                  const numAmount = parseFloat(amount || '0');
                  if (numAmount > 0) {
                    setSavingsGoal(numAmount);
                    Alert.alert('Success', `Savings goal set to ₹${numAmount.toLocaleString()}!`);
                  }
                },
                'plain-text',
                '',
                'numeric'
              );
            }
          },
        ]
      );
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading dashboard...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!user) {
    return null;
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const StatCard = ({ 
    title, 
    value, 
    change, 
    icon: Icon, 
    positive 
  }: {
    title: string;
    value: string;
    change?: string;
    icon: any;
    positive?: boolean;
  }) => (
    <View style={styles.statCard}>
      <View style={styles.statHeader}>
        <View style={[styles.iconContainer, { backgroundColor: positive ? '#DCFCE7' : '#FEF3C7' }]}>
          <Icon 
            size={20} 
            color={positive ? '#16A34A' : '#F59E0B'} 
          />
        </View>
        {change && (
          <View style={[styles.changeContainer, { backgroundColor: positive ? '#DCFCE7' : '#FEE2E2' }]}>
            <Text style={[styles.changeText, { color: positive ? '#16A34A' : '#DC2626' }]}>
              {change}
            </Text>
          </View>
        )}
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statTitle}>{title}</Text>
    </View>
  );

  const QuickAction = ({ 
    title, 
    icon: Icon, 
    color, 
    onPress 
  }: {
    title: string;
    icon: any;
    color: string;
    onPress: () => void;
  }) => (
    <TouchableOpacity 
      style={styles.quickAction} 
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.quickActionIcon, { backgroundColor: color }]}>
        <Icon size={24} color="white" />
      </View>
      <Text style={styles.quickActionText}>{title}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient
        colors={['#14B8A6', '#3B82F6']}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.greeting}>Good morning,</Text>
            <Text style={styles.userName}>{user.full_name || 'User'}</Text>
          </View>
          <TouchableOpacity 
            style={styles.profileButton}
            onPress={() => router.push('/(tabs)/profile')}
          >
            <View style={styles.profileAvatar}>
              <Text style={styles.profileInitial}>
                {(user.full_name || user.email)?.[0]?.toUpperCase()}
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.balanceCard}>
          <View style={styles.balanceHeader}>
            <Text style={styles.balanceLabel}>Total Balance</Text>
            <Eye size={16} color="rgba(255, 255, 255, 0.8)" />
          </View>
          <Text style={styles.balanceAmount}>{formatCurrency(financialData.balance)}</Text>
          <View style={styles.balanceChange}>
            <TrendingUp size={16} color="#10B981" />
            <Text style={styles.balanceChangeText}>
              +{financialData.monthlyChange}% from last month
            </Text>
          </View>
        </View>
      </LinearGradient>

      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.statsGrid}>
          <StatCard
            title="Monthly Income"
            value={formatCurrency(financialData.totalIncome)}
            change="+8.2%"
            icon={TrendingUp}
            positive={true}
          />
          <StatCard
            title="Monthly Expenses"
            value={formatCurrency(financialData.totalExpenses)}
            change="-2.1%"
            icon={TrendingDown}
            positive={false}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Savings Goal</Text>
          <TouchableOpacity 
            style={styles.goalCard}
            onPress={handleSetGoal}
            activeOpacity={0.8}
          >
            <View style={styles.goalHeader}>
              <Target size={24} color="#14B8A6" />
              <Text style={styles.goalAmount}>
                {formatCurrency(financialData.balance)} / {formatCurrency(financialData.savingsGoal)}
              </Text>
            </View>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill, 
                  { width: `${Math.min(financialData.savingsProgress, 100)}%` }
                ]} 
              />
            </View>
            <Text style={styles.goalProgress}>
              {financialData.savingsProgress}% complete • Tap to update goal
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.quickActions}>
            <QuickAction
              title="Add Income"
              icon={Plus}
              color="#10B981"
              onPress={handleAddIncome}
            />
            <QuickAction
              title="Add Expense"
              icon={CreditCard}
              color="#EF4444"
              onPress={handleAddExpense}
            />
            <QuickAction
              title="View Budget"
              icon={PieChart}
              color="#3B82F6"
              onPress={() => router.push('/(tabs)/budget')}
            />
            <QuickAction
              title="Set Goal"
              icon={Target}
              color="#8B5CF6"
              onPress={handleSetGoal}
            />
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Transactions</Text>
            <TouchableOpacity onPress={() => Alert.alert('Coming Soon', 'Full transaction history will be available soon!')}>
              <Text style={styles.seeAll}>See All</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.transactionsList}>
            <TouchableOpacity 
              style={styles.transaction}
              onPress={() => Alert.alert('Transaction Details', 'Grocery Shopping - ₹850\nDate: Today\nCategory: Food & Dining')}
            >
              <View style={styles.transactionIcon}>
                <CreditCard size={20} color="#EF4444" />
              </View>
              <View style={styles.transactionDetails}>
                <Text style={styles.transactionTitle}>Grocery Shopping</Text>
                <Text style={styles.transactionDate}>Today</Text>
              </View>
              <Text style={styles.transactionAmount}>-₹850</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.transaction}
              onPress={() => Alert.alert('Transaction Details', 'Salary - ₹50,000\nDate: Yesterday\nCategory: Income')}
            >
              <View style={styles.transactionIcon}>
                <DollarSign size={20} color="#10B981" />
              </View>
              <View style={styles.transactionDetails}>
                <Text style={styles.transactionTitle}>Salary</Text>
                <Text style={styles.transactionDate}>Yesterday</Text>
              </View>
              <Text style={[styles.transactionAmount, styles.positive]}>+₹50,000</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      <InputModal
        visible={modalVisible}
        title={modalConfig.title}
        placeholder={modalConfig.placeholder}
        onSubmit={modalConfig.onSubmit}
        onCancel={() => setModalVisible(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  header: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  greeting: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
    fontFamily: 'Inter-Regular',
  },
  userName: {
    fontSize: 24,
    color: 'white',
    fontFamily: 'Inter-Bold',
    marginTop: 4,
  },
  profileButton: {
    padding: 4,
  },
  profileAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileInitial: {
    fontSize: 16,
    color: 'white',
    fontFamily: 'Inter-Bold',
  },
  balanceCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 16,
    padding: 20,
  },
  balanceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  balanceLabel: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    fontFamily: 'Inter-Regular',
    marginRight: 8,
  },
  balanceAmount: {
    fontSize: 32,
    color: 'white',
    fontFamily: 'Inter-Bold',
    marginBottom: 8,
  },
  balanceChange: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  balanceChangeText: {
    fontSize: 14,
    color: '#10B981',
    fontFamily: 'Inter-Medium',
    marginLeft: 4,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 100,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  statHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  changeContainer: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  changeText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  statTitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  seeAll: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#14B8A6',
  },
  goalCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  goalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  goalAmount: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginLeft: 12,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#E5E7EB',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#14B8A6',
    borderRadius: 4,
  },
  goalProgress: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    textAlign: 'center',
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  quickAction: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  quickActionText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
    textAlign: 'center',
  },
  transactionsList: {
    backgroundColor: 'white',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  transaction: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  transactionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  transactionDetails: {
    flex: 1,
  },
  transactionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
  },
  transactionDate: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 2,
  },
  transactionAmount: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#EF4444',
  },
  positive: {
    color: '#10B981',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContainer: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 10,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  closeButton: {
    padding: 4,
  },
  modalInput: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
    marginBottom: 24,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalCancelButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  modalSubmitButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#14B8A6',
    alignItems: 'center',
  },
  modalSubmitText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
});
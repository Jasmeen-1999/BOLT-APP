import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '@/contexts/AuthContext';
import { router } from 'expo-router';
import { User, Settings, Bell, Shield, CreditCard, Crown, CircleHelp as HelpCircle, LogOut, ChevronRight, Mail, Smartphone, Globe, Star, Award, Calendar } from 'lucide-react-native';

export default function Settings() {
  const { user, signOut } = useAuth();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [emailUpdates, setEmailUpdates] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  const handleSignOut = async () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign Out', style: 'destructive', onPress: async () => {
          await signOut();
          router.replace('/(auth)/sign-in');
        }},
      ]
    );
  };

  const upgradeToPremium = () => {
    Alert.alert(
      'Upgrade to Premium',
      'Get advanced analytics, unlimited AI coaching, and exclusive blockchain rewards!',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Upgrade', onPress: () => {
          // Implement RevenueCat subscription
          Alert.alert('Coming Soon', 'Premium subscription will be available soon!');
        }},
      ]
    );
  };

  const handlePersonalInfo = () => {
    Alert.alert('Personal Information', 'Edit your name, email, and profile settings.\n\nThis feature will be available soon!');
  };

  const handlePaymentMethods = () => {
    Alert.alert('Payment Methods', 'Manage your payment options and billing information.\n\nThis feature will be available soon!');
  };

  const handlePrivacySecurity = () => {
    Alert.alert('Privacy & Security', 'Update your password and enable two-factor authentication.\n\nThis feature will be available soon!');
  };

  const handleLanguageRegion = () => {
    Alert.alert('Language & Region', 'Change your language and regional settings.\n\nCurrently set to: English (India)');
  };

  const handleAdvancedAnalytics = () => {
    if (user?.is_premium) {
      Alert.alert('Advanced Analytics', 'View detailed financial reports and insights.\n\nThis feature will be available soon!');
    } else {
      upgradeToPremium();
    }
  };

  const handleExclusiveRewards = () => {
    if (user?.is_premium) {
      router.push('/(tabs)/rewards');
    } else {
      upgradeToPremium();
    }
  };

  const handleCustomGoals = () => {
    if (user?.is_premium) {
      Alert.alert('Custom Goals', 'Set unlimited financial goals and track your progress.\n\nThis feature will be available soon!');
    } else {
      upgradeToPremium();
    }
  };

  const handleHelpSupport = () => {
    Alert.alert(
      'Help & Support',
      'Need help? Contact our support team:\n\n📧 support@financecoach.app\n📱 +1 (555) 123-4567\n\nOr visit our help center for FAQs and guides.',
      [
        { text: 'OK', style: 'default' },
        { text: 'Email Support', onPress: () => {
          Alert.alert('Email Support', 'Opening your email app to contact support@financecoach.app');
        }},
      ]
    );
  };

  const ProfileSection = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.sectionContent}>
        {children}
      </View>
    </View>
  );

  const ProfileRow = ({ 
    icon: Icon, 
    title, 
    subtitle, 
    onPress, 
    showChevron = true,
    rightElement
  }: {
    icon: any;
    title: string;
    subtitle?: string;
    onPress?: () => void;
    showChevron?: boolean;
    rightElement?: React.ReactNode;
  }) => (
    <TouchableOpacity 
      style={[styles.profileRow, !onPress && styles.profileRowDisabled]} 
      onPress={onPress} 
      disabled={!onPress}
      activeOpacity={onPress ? 0.7 : 1}
    >
      <View style={styles.rowLeft}>
        <View style={styles.rowIcon}>
          <Icon size={20} color="#6B7280" />
        </View>
        <View style={styles.rowContent}>
          <Text style={styles.rowTitle}>{title}</Text>
          {subtitle && <Text style={styles.rowSubtitle}>{subtitle}</Text>}
        </View>
      </View>
      <View style={styles.rowRight}>
        {rightElement}
        {showChevron && onPress && <ChevronRight size={16} color="#9CA3AF" />}
      </View>
    </TouchableOpacity>
  );

  if (!user) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Please sign in to access settings</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {(user.full_name || user.email)?.[0]?.toUpperCase()}
            </Text>
          </View>
          {user.is_premium && (
            <View style={styles.premiumBadge}>
              <Crown size={12} color="#F59E0B" />
            </View>
          )}
        </View>
        <Text style={styles.userName}>{user.full_name || 'User'}</Text>
        <Text style={styles.userEmail}>{user.email}</Text>
        
        {!user.is_premium && (
          <TouchableOpacity style={styles.upgradeButton} onPress={upgradeToPremium}>
            <Crown size={16} color="white" />
            <Text style={styles.upgradeText}>Upgrade to Premium</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView 
        style={styles.scrollView} 
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <ProfileSection title="Account">
          <ProfileRow
            icon={User}
            title="Personal Information"
            subtitle="Name, email, and profile settings"
            onPress={handlePersonalInfo}
          />
          <ProfileRow
            icon={CreditCard}
            title="Payment Methods"
            subtitle="Manage your payment options"
            onPress={handlePaymentMethods}
          />
          <ProfileRow
            icon={Shield}
            title="Privacy & Security"
            subtitle="Password, two-factor authentication"
            onPress={handlePrivacySecurity}
          />
        </ProfileSection>

        <ProfileSection title="Preferences">
          <ProfileRow
            icon={Bell}
            title="Push Notifications"
            subtitle="Get notified about your financial goals"
            showChevron={false}
            rightElement={
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
                trackColor={{ false: '#E5E7EB', true: '#14B8A6' }}
                thumbColor={notificationsEnabled ? '#ffffff' : '#ffffff'}
              />
            }
          />
          <ProfileRow
            icon={Mail}
            title="Email Updates"
            subtitle="Weekly financial summaries and tips"
            showChevron={false}
            rightElement={
              <Switch
                value={emailUpdates}
                onValueChange={setEmailUpdates}
                trackColor={{ false: '#E5E7EB', true: '#14B8A6' }}
                thumbColor={emailUpdates ? '#ffffff' : '#ffffff'}
              />
            }
          />
          <ProfileRow
            icon={Globe}
            title="Language & Region"
            subtitle="English (India)"
            onPress={handleLanguageRegion}
          />
        </ProfileSection>

        <ProfileSection title="Premium Features">
          <ProfileRow
            icon={Star}
            title="Advanced Analytics"
            subtitle={user.is_premium ? "View detailed reports" : "Unlock with Premium"}
            onPress={handleAdvancedAnalytics}
          />
          <ProfileRow
            icon={Award}
            title="Exclusive Rewards"
            subtitle={user.is_premium ? "Access premium blockchain rewards" : "Upgrade to unlock"}
            onPress={handleExclusiveRewards}
          />
          <ProfileRow
            icon={Calendar}
            title="Custom Goals"
            subtitle={user.is_premium ? "Set unlimited financial goals" : "Premium feature"}
            onPress={handleCustomGoals}
          />
        </ProfileSection>

        <ProfileSection title="Support">
          <ProfileRow
            icon={HelpCircle}
            title="Help & Support"
            subtitle="Get help with your account"
            onPress={handleHelpSupport}
          />
          <ProfileRow
            icon={Smartphone}
            title="App Version"
            subtitle="Version 1.0.0"
            showChevron={false}
          />
        </ProfileSection>

        <View style={styles.dangerSection}>
          <TouchableOpacity style={styles.signOutButton} onPress={handleSignOut}>
            <LogOut size={20} color="#EF4444" />
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Made with ❤️ for better financial health
          </Text>
          <Text style={styles.footerVersion}>
            Personal Finance Coach v1.0.0
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#EF4444',
    textAlign: 'center',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 100,
  },
  header: {
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 32,
    paddingBottom: 32,
    backgroundColor: 'white',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#14B8A6',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  avatarText: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: 'white',
  },
  premiumBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FEF3C7',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'white',
  },
  userName: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 16,
  },
  upgradeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F59E0B',
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  upgradeText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
    marginLeft: 8,
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  sectionContent: {
    backgroundColor: 'white',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  profileRowDisabled: {
    opacity: 0.6,
  },
  rowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  rowIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  rowContent: {
    flex: 1,
  },
  rowTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
  },
  rowSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 2,
  },
  rowRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  dangerSection: {
    paddingHorizontal: 24,
    marginTop: 24,
  },
  signOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    borderRadius: 16,
    paddingVertical: 16,
    borderWidth: 1,
    borderColor: '#FEE2E2',
  },
  signOutText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#EF4444',
    marginLeft: 8,
  },
  footer: {
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 32,
    paddingBottom: 24,
  },
  footerText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 8,
  },
  footerVersion: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
  },
});
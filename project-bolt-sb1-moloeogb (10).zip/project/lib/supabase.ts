import { createClient } from '@supabase/supabase-js';
import { Database } from '../types/database';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

// Check if environment variables are properly configured
if (!supabaseUrl || supabaseUrl === 'your_supabase_url_here' || !supabaseUrl.startsWith('https://')) {
  throw new Error('EXPO_PUBLIC_SUPABASE_URL is not properly configured. Please set it to your actual Supabase project URL in the .env file.');
}

if (!supabaseAnonKey || supabaseAnonKey === 'your_supabase_anon_key_here') {
  throw new Error('EXPO_PUBLIC_SUPABASE_ANON_KEY is not properly configured. Please set it to your actual Supabase anon key in the .env file.');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    redirectTo: 'https://zp1v56uxy8rdx5ypatb0ockcb9tr6a-oci3--8081--6a59aef5.local-credentialless.webcontainer-api.io/sign-in',
  },
});
